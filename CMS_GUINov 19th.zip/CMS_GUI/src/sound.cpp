#include "sound.h"
#include <windows.h>
#include <mmsystem.h>
#include <stdio.h>
#include <math.h>

// BUFFERS
short iBigBuf[SAMPLES_SEC * RECORD_TIME];
long lBigBufSize = SAMPLES_SEC * RECORD_TIME;

static int g_nSamplesPerSec = SAMPLES_SEC;
static int g_nBitsPerSample = 16;
static HWAVEOUT HWaveOut;
static HWAVEIN HWaveIn;
static WAVEFORMATEX WaveFormat;
static WAVEHDR WaveHeader[NFREQUENCIES];
static WAVEHDR WaveHeaderSilence;
static WAVEHDR WaveHeaderIn;

static void SetupFormat(WAVEFORMATEX* wf);
static int WaitOnHeader(WAVEHDR* wh, char cDit);

int InitializePlayback(void) {
    SetupFormat(&WaveFormat);
    int rc = waveOutOpen(&HWaveOut, WAVE_MAPPER, &WaveFormat, (DWORD)NULL, 0, CALLBACK_NULL);
    if (rc) {
        printf("ERROR: waveOutOpen failed with code 0x%x\n", rc);
        return 0;
    }
    return 1;
}

int PlayBuffer(short *piBuf, long lSamples) {
    WAVEHDR WaveHeader;

    waveOutReset(HWaveOut);

    WaveHeader.lpData = (char *)piBuf;
    WaveHeader.dwBufferLength = lSamples * sizeof(short);
    int rc = waveOutPrepareHeader(HWaveOut, &WaveHeader, sizeof(WAVEHDR));
    if (rc) {
        printf("ERROR: waveOutPrepareHeader failed with code 0x%x\n", rc);
        return 0;
    }

    WaveHeader.dwFlags &= ~(WHDR_BEGINLOOP | WHDR_ENDLOOP);

    MMRESULT mmErr = waveOutWrite(HWaveOut, &WaveHeader, sizeof(WAVEHDR));
    if (mmErr) {
        printf("ERROR: waveOutWrite failed with code 0x%x\n", mmErr);
        waveOutUnprepareHeader(HWaveOut, &WaveHeader, sizeof(WAVEHDR));
        return 0;
    }

    rc = WaitOnHeader(&WaveHeader, 0);
    waveOutUnprepareHeader(HWaveOut, &WaveHeader, sizeof(WAVEHDR));

    return rc;
}

void ClosePlayback(void) {
    waveOutReset(HWaveOut);
    for (int i = 0; i < NFREQUENCIES; ++i) {
        waveOutUnprepareHeader(HWaveOut, &WaveHeader[i], sizeof(WAVEHDR));
    }
    waveOutClose(HWaveOut);
}

int InitializeRecording(void) {
    SetupFormat(&WaveFormat);

    printf("Attempting to open recording device...\n");
    MMRESULT rc = waveInOpen(&HWaveIn, WAVE_MAPPER, &WaveFormat, (DWORD)NULL, 0, CALLBACK_NULL);
    if (rc) {
        printf("\n=== RECORDING DEVICE ERROR ===\n");
        printf("waveInOpen failed with error code: 0x%x\n", rc);
        printf("Common error codes:\n");
        printf("  0x02 = MMSYSERR_BADDEVICEID (No recording device)\n");
        printf("  0x04 = MMSYSERR_ALLOCATED (Device in use)\n");
        printf("  0x08 = MMSYSERR_NODRIVER (No driver installed)\n");
        printf("\nTroubleshooting:\n");
        printf("1. Check Windows Sound Settings -> Recording tab\n");
        printf("2. Ensure microphone is ENABLED and set as DEFAULT\n");
        printf("3. Close other apps using microphone (Zoom, Teams, etc)\n");
        printf("4. Check Privacy Settings -> Microphone -> Allow apps\n");
        printf("============================\n\n");
        return 0;
    }

    printf("Recording device opened successfully\n");

    WaveHeaderIn.lpData = (char *)iBigBuf;
    WaveHeaderIn.dwBufferLength = lBigBufSize * sizeof(short);
    rc = waveInPrepareHeader(HWaveIn, &WaveHeaderIn, sizeof(WAVEHDR));
    if (rc) {
        printf("ERROR: waveInPrepareHeader failed with code 0x%x\n", rc);
        waveInClose(HWaveIn);
        return 0;
    }

    printf("Recording buffers prepared\n");
    return 1;
}

int RecordBuffer(short *piBuf, long lBufSize) {
    WAVEHDR WaveHeader;

    printf("\n=== STARTING RECORDING ===\n");
    printf("Buffer size: %ld samples (%ld bytes)\n", lBufSize, lBufSize * sizeof(short));

    waveInReset(HWaveIn);

    WaveHeader.lpData = (char *)piBuf;
    WaveHeader.dwBufferLength = lBufSize * sizeof(short);
    WaveHeader.dwFlags = 0;
    WaveHeader.dwLoops = 0;

    printf("Preparing header...\n");
    int rc = waveInPrepareHeader(HWaveIn, &WaveHeader, sizeof(WAVEHDR));
    if (rc) {
        printf("ERROR: waveInPrepareHeader failed with code 0x%x\n", rc);
        return 0;
    }

    WaveHeader.dwFlags &= ~(WHDR_BEGINLOOP | WHDR_ENDLOOP);

    printf("Adding buffer to recording queue...\n");
    MMRESULT mmErr = waveInAddBuffer(HWaveIn, &WaveHeader, sizeof(WAVEHDR));
    if (mmErr) {
        printf("ERROR: waveInAddBuffer failed with code 0x%x\n", mmErr);
        waveInUnprepareHeader(HWaveIn, &WaveHeader, sizeof(WAVEHDR));
        return 0;
    }

    printf("Starting recording... SPEAK NOW!\n");
    mmErr = waveInStart(HWaveIn);
    if (mmErr) {
        printf("ERROR: waveInStart failed with code 0x%x\n", mmErr);
        waveInUnprepareHeader(HWaveIn, &WaveHeader, sizeof(WAVEHDR));
        return 0;
    }

    printf("Recording");
    fflush(stdout);
    rc = WaitOnHeader(&WaveHeader, '.');
    printf("\n");

    waveInStop(HWaveIn);
    waveInUnprepareHeader(HWaveIn, &WaveHeader, sizeof(WAVEHDR));

    if (rc) {
        printf("=== RECORDING COMPLETED SUCCESSFULLY ===\n\n");
    } else {
        printf("=== RECORDING TIMED OUT OR FAILED ===\n");
        printf("The recording did not complete within 10 seconds.\n");
        printf("This usually means:\n");
        printf("- Microphone is not working\n");
        printf("- Audio driver issue\n");
        printf("- Permissions problem\n\n");
    }

    return rc;
}

void CloseRecording(void) {
    waveInReset(HWaveIn);
    waveInUnprepareHeader(HWaveIn, &WaveHeaderIn, sizeof(WAVEHDR));
    waveInClose(HWaveIn);
}

static void SetupFormat(WAVEFORMATEX* wf) {
    wf->wFormatTag = WAVE_FORMAT_PCM;
    wf->nChannels = 1;
    wf->nSamplesPerSec = g_nSamplesPerSec;
    wf->wBitsPerSample = g_nBitsPerSample;
    wf->nBlockAlign = wf->nChannels * (wf->wBitsPerSample / 8);
    wf->nAvgBytesPerSec = wf->nSamplesPerSec * wf->nBlockAlign;
    wf->cbSize = 0;
}

static int WaitOnHeader(WAVEHDR* wh, char cDit) {
    long lTime = 0;
    while (1) {
        if (wh->dwFlags & WHDR_DONE) return 1;
        Sleep(100L);
        lTime += 100;
        if (lTime >= 10000) {
            printf("\nTIMEOUT: Recording did not complete in 10 seconds\n");
            return 0;
        }
        if (cDit) {
            printf("%c", cDit);
            fflush(stdout);
        }
    }
}

void saveAudio(short* buffer, long size, const char* filename) {
    char filePath[256];
    snprintf(filePath, sizeof(filePath), "./%s.dat", filename);

    FILE* f = fopen(filePath, "wb");
    if (f) {
        fwrite(buffer, sizeof(short), size, f);
        fclose(f);
        printf("Audio saved to: %s\n", filePath);
    } else {
        printf("ERROR: Could not open file for writing: %s\n", filePath);
    }
}
