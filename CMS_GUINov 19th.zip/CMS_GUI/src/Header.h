#ifndef HEADER_H
#define HEADER_H

// Forward declarations for Windows types to avoid conflicts
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#endif

#endif // HEADER_H
