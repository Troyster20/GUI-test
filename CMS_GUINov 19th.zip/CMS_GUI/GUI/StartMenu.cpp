#include "StartMenu.h"
#include "ui_StartMenu.h"
#include <QMessageBox>

StartMenu::StartMenu(CMSController* controller, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::StartMenu),
    m_controller(controller)
{
    ui->setupUi(this);

    // Add helpful info on startup
    QMessageBox::information(this, "CMS Project - Group Mate Integration",
                             "✓ Using group mate's working protocol!\n\n"
                             "Features:\n"
                             "• Audio transmission @ 460800 baud\n"
                             "• Header + Payload protocol\n"
                             "• Text messaging\n"
                             "• Audio recording & playback\n"
                             "• Queue management\n\n"
                             "Ready to use!");
}

StartMenu::~StartMenu()
{
    delete ui;
}

void StartMenu::on_transmitButton_clicked()
{
    emit showTransmitter();
}

void StartMenu::on_receiveButton_clicked()
{
    emit showReceiver();
}

void StartMenu::on_testingButton_clicked()
{
    emit showTesting();
}

void StartMenu::on_phonebookButton_clicked()
{
    emit showPhonebook();
}

void StartMenu::on_settingsButton_clicked()
{
    emit showSettings();
}

void StartMenu::on_quitButton_clicked()
{
    emit quitApplication();
}
