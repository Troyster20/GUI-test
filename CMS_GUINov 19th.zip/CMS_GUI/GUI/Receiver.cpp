#include "Receiver.h"
#include "ui_Receiver.h"

// ALL Qt includes
#include <QMessageBox>
#include <QDateTime>
#include <QString>
#include <QStringList>

Receiver::Receiver(CMSController* controller, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Receiver),
    m_controller(controller),
    m_currentSender("Unknown"),
    m_isEncrypted(false),
    m_isCompressed(false)
{
    ui->setupUi(this);

    connect(m_controller, &CMSController::messageReceived, this, &Receiver::onMessageReceived);
    connect(m_controller, &CMSController::playbackFinished, this, &Receiver::onPlaybackFinished);
    connect(m_controller, &CMSController::errorOccurred, this, &Receiver::onErrorOccurred);

    if (!m_controller->initializeReceiver()) {
        QMessageBox::warning(this, "COM Port Warning",
                             "Receiver COM port initialization failed.\n"
                             "Check COM7 availability.");
    }

    updateQueueInfo();
}

Receiver::~Receiver()
{
    delete ui;
}

void Receiver::on_backButton_clicked()
{
    emit backToStart();
}

void Receiver::on_playTextButton_clicked()
{
    QMessageBox::information(this, "Receiving Text",
                             "Waiting for text message...\n\n"
                             "Will wait up to 10 seconds.\n"
                             "Make sure transmitter sends NOW!");

    QString message = m_controller->receiveTextMessage();

    if (!message.isEmpty()) {
        if (message.contains('|') && message.contains('\n')) {
            int headerEnd = message.indexOf('\n');
            QString header = message.left(headerEnd);
            QString messageBody = message.mid(headerEnd + 1);

            parseMessageHeader(header);
            ui->receivedTextEdit->setPlainText(messageBody);
        } else {
            ui->receivedTextEdit->setPlainText(message);
            m_currentSender = "Unknown";
            m_messageTime = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
        }

        ui->senderLabel->setText("From: " + m_currentSender);
        ui->timeLabel->setText("Time: " + m_messageTime);
        ui->decryptCheckBox->setChecked(m_isEncrypted);
        ui->decompressCheckBox->setChecked(m_isCompressed);

        QMessageBox::information(this, "Text Message", "Text message received and displayed");
    } else {
        QMessageBox::information(this, "No Message", "No message received (timeout)");
    }
}

void Receiver::on_playAudioButton_clicked()
{
    QMessageBox::information(this, "Receiving Audio",
                             "Ready to receive audio message!\n\n"
                             "Protocol: Header + Payload @ 460800 baud\n\n"
                             "Will wait for transmission.\n"
                             "Click OK, then transmitter should send.");

    bool success = m_controller->receiveAudioMessage();

    if (success) {
        updateQueueInfo();
        QMessageBox::information(this, "Success",
                                 "Audio received and added to queue!\n\n"
                                 "The received audio is now in the queue.\n"
                                 "Go to Transmitter screen to play it.");
    }
}

void Receiver::on_viewHeaderButton_clicked()
{
    QString headerInfo = QString(
                             "=== RECEIVER STATUS ===\n\n"
                             "Protocol: Header + Payload\n"
                             "Baud Rate: 460800\n"
                             "Port: COM7\n"
                             "Sender: %1\n"
                             "Timestamp: %2\n"
                             "Encrypted: %3\n"
                             "Compressed: %4\n\n"
                             "Audio Queue: %5 messages\n\n"
                             "Using group mate's working protocol!")
                             .arg(m_currentSender)
                             .arg(m_messageTime)
                             .arg(m_isEncrypted ? "Yes" : "No")
                             .arg(m_isCompressed ? "Yes" : "No")
                             .arg(m_controller->getMessageCount());

    QMessageBox::information(this, "Receiver Info", headerInfo);
}

void Receiver::on_checkErrorsButton_clicked()
{
    QString message = ui->receivedTextEdit->toPlainText();

    bool hasErrors = false;
    QString errorReport = "=== ERROR CHECK ===\n\n";

    if (message.isEmpty()) {
        errorReport += "No message to check.\n";
    } else {
        if (message.length() < 1) {
            hasErrors = true;
            errorReport += "- Message too short\n";
        }

        if (message.contains("�") || message.contains("??")) {
            hasErrors = true;
            errorReport += "- Character encoding errors detected\n";
        }

        if (!hasErrors) {
            errorReport += "✓ No errors detected\n";
            errorReport += "✓ Message integrity: OK\n";
            errorReport += "✓ Transmission quality: Good";
        } else {
            errorReport += "⚠ Message may be corrupted";
        }
    }

    errorReport += QString("\n\nAudio Queue: %1 messages").arg(m_controller->getMessageCount());

    QMessageBox::information(this, "Error Check", errorReport);
}

void Receiver::onMessageReceived(const QString& message)
{
    if (!message.isEmpty()) {
        if (message.contains('|') && message.contains('\n')) {
            int headerEnd = message.indexOf('\n');
            QString header = message.left(headerEnd);
            QString messageBody = message.mid(headerEnd + 1);

            parseMessageHeader(header);
            ui->receivedTextEdit->setPlainText(messageBody);
        } else {
            ui->receivedTextEdit->setPlainText(message);
        }

        ui->senderLabel->setText("From: " + m_currentSender);
        ui->timeLabel->setText("Time: " + m_messageTime);
    }
}

void Receiver::parseMessageHeader(const QString& header)
{
    m_currentSender = "Unknown";
    m_messageTime = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
    m_isEncrypted = false;
    m_isCompressed = false;

    QStringList parts = header.split('|');
    for (const QString& part : parts) {
        if (part.startsWith("TO:")) {
            m_currentSender = part.mid(3);
        } else if (part.startsWith("TIME:")) {
            QString timeStr = part.mid(5);
            QDateTime dt = QDateTime::fromString(timeStr, "yyyyMMdd-hhmmss");
            if (dt.isValid()) {
                m_messageTime = dt.toString("yyyy-MM-dd hh:mm:ss");
            }
        } else if (part.startsWith("ENCRYPT:")) {
            m_isEncrypted = (part.mid(8) == "Y");
        } else if (part.startsWith("COMPRESS:")) {
            m_isCompressed = (part.mid(9) == "Y");
        }
    }
}

void Receiver::onPlaybackFinished(bool success, const QString& message)
{
    if (success) {
        QMessageBox::information(this, "Playback", message);
    } else {
        QMessageBox::critical(this, "Playback Error", message);
    }
}

void Receiver::onErrorOccurred(const QString& error)
{
    QMessageBox::critical(this, "Error", error);
}

void Receiver::updateQueueInfo()
{
    int messageCount = m_controller->getMessageCount();
    QString currentMessage = m_controller->getCurrentMessageName();

    QString queueInfo = QString("Audio queue: %1 messages\nCurrent: %2")
                            .arg(messageCount)
                            .arg(currentMessage.isEmpty() ? "None" : currentMessage);

    ui->playAudioButton->setToolTip(queueInfo);
}
