#ifndef RECEIVER_H
#define RECEIVER_H

#include <QWidget>
#include <QString>
#include "CMSController.h"

namespace Ui {
class Receiver;
}

class Receiver : public QWidget
{
    Q_OBJECT

public:
    explicit Receiver(CMSController* controller, QWidget *parent = nullptr);
    ~Receiver();

signals:
    void backToStart();

private slots:
    void on_backButton_clicked();
    void on_playTextButton_clicked();
    void on_playAudioButton_clicked();
    void on_viewHeaderButton_clicked();
    void on_checkErrorsButton_clicked();

    void onMessageReceived(const QString& message);
    void onPlaybackFinished(bool success, const QString& message);
    void onErrorOccurred(const QString& error);

private:
    void parseMessageHeader(const QString& header);
    void updateQueueInfo();

    Ui::Receiver *ui;
    CMSController* m_controller;
    QString m_currentSender;
    QString m_messageTime;
    bool m_isEncrypted;
    bool m_isCompressed;
};

#endif // RECEIVER_H
