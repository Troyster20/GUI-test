#include "Settings.h"
#include "ui_Settings.h"
#include <QMessageBox>

Settings::Settings(CMSController* controller, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Settings),
    m_controller(controller)
{
    ui->setupUi(this);
    updateSettingsDisplay();
}

Settings::~Settings()
{
    delete ui;
}

void Settings::on_backButton_clicked()
{
    emit backToStart();
}

void Settings::on_saveButton_clicked()
{
    QString txPort = ui->txComEdit->text();
    QString rxPort = ui->rxComEdit->text();
    QString baudRate = ui->baudRateCombo->currentText();

    bool txSuccess = m_controller->initializeTransmitter(txPort);
    bool rxSuccess = m_controller->initializeReceiver(rxPort);

    QString message = "Settings saved!\n\n";
    message += QString("Transmitter: %1 (%2)\n").arg(txPort).arg(txSuccess ? "✓" : "✗ Failed");
    message += QString("Receiver: %1 (%2)\n").arg(rxPort).arg(rxSuccess ? "✓" : "✗ Failed");
    message += QString("Baud Rate: %1\n\n").arg(baudRate);
    message += "Using group mate's protocol:\n";
    message += "• Header + Payload transmission\n";
    message += "• 460800 baud for audio\n";
    message += "• Works with virtual COM ports!";

    QMessageBox::information(this, "Settings", message);
}

void Settings::on_defaultsButton_clicked()
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Restore Defaults",
                                  "Restore all settings to defaults?\n\n"
                                  "Transmitter: COM6\n"
                                  "Receiver: COM7\n"
                                  "Baud: 460800",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        ui->txComEdit->setText("COM6");
        ui->rxComEdit->setText("COM7");
        ui->baudRateCombo->setCurrentText("460800");
        ui->errorDetectionCheck->setChecked(true);
        ui->compressionCheck->setChecked(false);
        ui->autoSaveCheck->setChecked(true);
        ui->playSoundCheck->setChecked(true);

        QMessageBox::information(this, "Defaults Restored",
                                 "All settings restored to defaults.\n\n"
                                 "Transmitter: COM6\n"
                                 "Receiver: COM7\n"
                                 "Baud: 460800 (group mate's working rate)");
    }
}

void Settings::updateSettingsDisplay()
{
    ui->txComEdit->setText("COM6");
    ui->rxComEdit->setText("COM7");

    // Add 460800 to baud rate options if not present
    bool has460800 = false;
    for (int i = 0; i < ui->baudRateCombo->count(); i++) {
        if (ui->baudRateCombo->itemText(i) == "460800") {
            has460800 = true;
            break;
        }
    }
    if (!has460800) {
        ui->baudRateCombo->addItem("460800");
    }

    ui->baudRateCombo->setCurrentText("460800");
    ui->errorDetectionCheck->setChecked(true);
    ui->compressionCheck->setChecked(false);
    ui->autoSaveCheck->setChecked(true);
    ui->playSoundCheck->setChecked(true);
}
