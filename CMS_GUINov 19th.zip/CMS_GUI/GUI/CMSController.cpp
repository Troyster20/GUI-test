#include "CMSController.h"
#include <QDebug>
#include <QMessageBox>
#include <QInputDialog>
#include <QDateTime>
#include <QThread>
#include <QProgressDialog>
#include <QApplication>

#include "../src/sound.h"
#include "../src/audioQueue.h"
#include "../src/RS232Comm.h"

extern short iBigBuf[];
extern long lBigBufSize;
extern int nComRate;
extern int nComBits;
extern COMMTIMEOUTS timeout;

CMSController::CMSController(QObject *parent)
    : QObject(parent)
    , systemsInitialized(false)
    , m_hComTx(INVALID_HANDLE_VALUE)
    , m_hComRx(INVALID_HANDLE_VALUE)
{
    initializeSystems();
}

CMSController::~CMSController()
{
    cleanupSystems();
}

void CMSController::initializeSystems()
{
    if (!systemsInitialized) {
        qDebug() << "=== Initializing CMS Systems ===";
        qDebug() << "Baud rate: 460800 (group mate's working rate)";

        initQueue();
        qDebug() << "Queue initialized";

        if (InitializePlayback()) {
            qDebug() << "Playback device initialized successfully";
        } else {
            qDebug() << "WARNING: Playback initialization failed";
        }

        if (InitializeRecording()) {
            qDebug() << "Recording device initialized successfully";
        } else {
            qDebug() << "WARNING: Recording initialization failed";
        }

        systemsInitialized = true;
        qDebug() << "CMS Systems initialized";
    }
}

void CMSController::cleanupSystems()
{
    if (systemsInitialized) {
        qDebug() << "=== Cleaning up CMS Systems ===";

        ClosePlayback();
        CloseRecording();
        clearQueue();

        if (m_hComTx != INVALID_HANDLE_VALUE) {
            CloseHandle(m_hComTx);
            m_hComTx = INVALID_HANDLE_VALUE;
        }
        if (m_hComRx != INVALID_HANDLE_VALUE) {
            CloseHandle(m_hComRx);
            m_hComRx = INVALID_HANDLE_VALUE;
        }

        systemsInitialized = false;
        qDebug() << "CMS Systems cleaned up";
    }
}

bool CMSController::startRecording(const QString& filename)
{
    if (!systemsInitialized) {
        emit recordingFinished(false, "Systems not initialized");
        return false;
    }

    QByteArray ba = filename.toLocal8Bit();
    const char* name = ba.constData();

    qDebug() << "=== Starting Recording ===" << filename;

    bool success = RecordBuffer(iBigBuf, lBigBufSize);

    if (success) {
        qDebug() << "Recording completed successfully";
        enqueue(iBigBuf, lBigBufSize, name);
        qDebug() << "Message enqueued successfully";
        emit recordingFinished(true, QString("Recording '%1' completed!").arg(filename));
    } else {
        qDebug() << "RecordBuffer returned false";
        QString errorMsg = "RECORDING FAILED\n\n"
                           "Possible causes:\n"
                           "• Microphone not accessible\n"
                           "• Audio driver issue\n"
                           "• Microphone permissions denied\n\n"
                           "Check Windows Sound Settings:\n"
                           "1. Right-click speaker icon\n"
                           "2. Sounds → Recording tab\n"
                           "3. Ensure microphone is ENABLED and DEFAULT\n"
                           "4. Test microphone in Windows settings\n\n"
                           "Also check:\n"
                           "Windows Settings → Privacy → Microphone";

        emit recordingFinished(false, errorMsg);
        emit errorOccurred(errorMsg);
    }

    return success;
}

bool CMSController::playCurrentAudio()
{
    if (!systemsInitialized || isQueueEmpty()) {
        emit playbackFinished(false, "No audio to play");
        return false;
    }

    link frontNode = peekQueue();
    if (!frontNode) {
        emit playbackFinished(false, "No audio message");
        return false;
    }

    QString messageName = QString::fromLocal8Bit(frontNode->Data.filename);
    qDebug() << "=== Playing audio ===" << messageName;

    bool success = PlayBuffer(frontNode->Data.buffer, frontNode->Data.size);

    if (success) {
        emit playbackFinished(true, "Playback complete");
    } else {
        emit playbackFinished(false, "Playback failed");
    }

    return success;
}

bool CMSController::saveCurrentAudio(const QString& filename)
{
    if (!systemsInitialized || isQueueEmpty()) return false;

    link frontNode = peekQueue();
    if (!frontNode) return false;

    QByteArray ba = filename.toLocal8Bit();
    saveAudio(frontNode->Data.buffer, frontNode->Data.size, ba.constData());

    return true;
}

bool CMSController::deleteCurrentAudio()
{
    if (!systemsInitialized || isQueueEmpty()) return false;

    link deleted = deQueue();
    if (deleted) {
        free(deleted->Data.buffer);
        free(deleted);
        return true;
    }
    return false;
}

bool CMSController::initializeTransmitter(const QString& portName)
{
    if (!systemsInitialized) return false;

    if (m_hComTx != INVALID_HANDLE_VALUE) {
        CloseHandle(m_hComTx);
        m_hComTx = INVALID_HANDLE_VALUE;
    }

    std::wstring port = portName.toStdWString();
    m_hComTx = setupComPort(port.c_str(), nComRate, nComBits, timeout);

    bool success = (m_hComTx != INVALID_HANDLE_VALUE);

    if (success) {
        qDebug() << "Transmitter initialized on" << portName << "at 460800 baud";
    }

    return success;
}

bool CMSController::initializeReceiver(const QString& portName)
{
    if (!systemsInitialized) return false;

    if (m_hComRx != INVALID_HANDLE_VALUE) {
        CloseHandle(m_hComRx);
        m_hComRx = INVALID_HANDLE_VALUE;
    }

    std::wstring port = portName.toStdWString();
    m_hComRx = setupComPort(port.c_str(), nComRate, nComBits, timeout);

    bool success = (m_hComRx != INVALID_HANDLE_VALUE);

    if (success) {
        qDebug() << "Receiver initialized on" << portName << "at 460800 baud";
    }

    return success;
}

bool CMSController::sendTextMessage(const QString& message)
{
    if (!systemsInitialized || message.isEmpty()) return false;

    if (m_hComTx == INVALID_HANDLE_VALUE) {
        if (!initializeTransmitter()) return false;
    }

    QByteArray ba = message.toLocal8Bit();
    outputToPort(&m_hComTx, ba.constData(), ba.length() + 1);

    emit messageSent(true, "Text message sent");
    return true;
}

QString CMSController::receiveTextMessage()
{
    if (!systemsInitialized) return QString();

    if (m_hComRx == INVALID_HANDLE_VALUE) {
        if (!initializeReceiver()) return QString();
    }

    char buffer[BUFSIZE];
    DWORD bytesRead = inputFromPort(&m_hComRx, buffer, BUFSIZE);

    if (bytesRead > 0) {
        buffer[bytesRead] = '\0';
        QString msg = QString::fromLocal8Bit(buffer);
        emit messageReceived(msg);
        return msg;
    }

    return QString();
}

int CMSController::getMessageCount() const
{
    extern int messageCount;
    return messageCount;
}

QString CMSController::getCurrentMessageName() const
{
    if (isQueueEmpty()) return QString();

    link frontNode = peekQueue();
    return frontNode ? QString::fromLocal8Bit(frontNode->Data.filename) : QString();
}

bool CMSController::sendAudioMessage(int queueIndex)
{
    qDebug() << "=== sendAudioMessage (GROUP MATE'S PROTOCOL) ===";
    qDebug() << "Sending message at index:" << queueIndex;

    if (!systemsInitialized) {
        qDebug() << "ERROR: Systems not initialized";
        QMessageBox::critical(nullptr, "Error", "Systems not initialized");
        return false;
    }

    link messageNode = getMessageAtIndex(queueIndex);
    if (!messageNode) {
        qDebug() << "ERROR: No message at index" << queueIndex;
        QMessageBox::critical(nullptr, "Error", "No message at index");
        return false;
    }

    if (m_hComTx == INVALID_HANDLE_VALUE) {
        qDebug() << "Transmitter not initialized, initializing now...";
        if (!initializeTransmitter()) {
            QMessageBox::critical(nullptr, "Error", "Cannot initialize transmitter");
            return false;
        }
    }

    QString filename = QString::fromLocal8Bit(messageNode->Data.filename);
    long numSamples = messageNode->Data.size;
    long payloadSize = numSamples * sizeof(short);

    qDebug() << "Sending AUDIO message:" << filename;
    qDebug() << "Size:" << payloadSize << "bytes (" << payloadSize / 1024 << "KB)";
    qDebug() << "At 460800 baud, estimated time: ~" << (payloadSize * 10) / 460800 << "seconds";

    Header txHeader;
    txHeader.sid = 1;
    txHeader.rid = 2;
    txHeader.priority = 0;
    txHeader.seqNum = 0;
    txHeader.payloadSize = payloadSize;
    txHeader.payLoadType = 'A';
    txHeader.encryption = 0;
    txHeader.compression = 0;

    QProgressDialog* progress = new QProgressDialog(
        QString("Sending audio '%1'...\n\n"
                "Size: %2 KB\n"
                "Protocol: Header + Payload @ 460800 baud\n\n"
                "Please wait...")
            .arg(filename)
            .arg(payloadSize / 1024),
        QString(), 0, 100, nullptr);

    progress->setWindowTitle("Transmitting Audio");
    progress->setMinimumDuration(0);
    progress->setCancelButton(nullptr);
    progress->setValue(10);
    progress->show();
    QApplication::processEvents();

    transmit(&txHeader, (void*)messageNode->Data.buffer, &m_hComTx);

    progress->setValue(100);
    progress->close();
    delete progress;

    qDebug() << "Audio transmission complete";

    QMessageBox::information(nullptr, "Success!",
                             QString("Audio transmitted successfully!\n\n"
                                     "Filename: %1\n"
                                     "Size: %2 KB")
                                 .arg(filename)
                                 .arg(payloadSize / 1024));

    emit messageSent(true, "Audio sent");
    return true;
}

bool CMSController::receiveAudioMessage()
{
    if (!systemsInitialized) {
        QMessageBox::critical(nullptr, "Error", "Systems not initialized");
        return false;
    }

    if (m_hComRx == INVALID_HANDLE_VALUE) {
        if (!initializeReceiver()) {
            QMessageBox::critical(nullptr, "Error", "Receiver not available");
            return false;
        }
    }

    qDebug() << "Waiting to receive audio message...";

    QProgressDialog* progress = new QProgressDialog(
        "Waiting for audio transmission...\n\n"
        "Protocol: Header + Payload @ 460800 baud\n\n"
        "Make sure transmitter sends NOW!",
        QString(), 0, 100, nullptr);

    progress->setWindowTitle("Receiving Audio");
    progress->setMinimumDuration(0);
    progress->setValue(10);
    progress->show();
    QApplication::processEvents();

    Header rxHeader;
    void* rxPayload = NULL;

    DWORD bytesRead = receive(&rxHeader, &rxPayload, &m_hComRx);

    progress->setValue(100);
    progress->close();
    delete progress;

    if (bytesRead == 0 || rxPayload == NULL) {
        QMessageBox::critical(nullptr, "Error", "No data received");
        qDebug() << "Reception failed";
        return false;
    }

    qDebug() << "Received payload:" << rxHeader.payloadSize << "bytes";
    qDebug() << "Type:" << rxHeader.payLoadType;

    if (rxHeader.payLoadType == 'A') {
        short* audioBuffer = (short*)rxPayload;
        long numSamples = rxHeader.payloadSize / sizeof(short);

        QString audioName = QString("Received_Audio_%1").arg(QDateTime::currentDateTime().toString("hhmmss"));
        enqueue(audioBuffer, numSamples, audioName.toLocal8Bit().constData());

        QString msg = QString("Audio received!\n\n"
                              "Size: %1 KB\n"
                              "Duration: %2 seconds\n\n"
                              "Added to queue - use 'Play Audio' to listen")
                          .arg(rxHeader.payloadSize / 1024)
                          .arg(numSamples / 8000);

        qDebug() << "Audio message received and queued";
        QMessageBox::information(nullptr, "Audio Received", msg);
        emit messageReceived(msg);

        free(rxPayload);
        return true;

    } else {
        free(rxPayload);
        QMessageBox::warning(nullptr, "Warning", "Received non-audio message");
        return false;
    }
}

QStringList CMSController::getQueueList() const
{
    QStringList list;
    int count = getQueueSize();
    for (int i = 0; i < count; i++) {
        link node = getMessageAtIndex(i);
        if (node) {
            list.append(QString("[%1] %2").arg(i).arg(QString::fromLocal8Bit(node->Data.filename)));
        }
    }
    return list;
}

bool CMSController::playMessageAtIndex(int index)
{
    link messageNode = getMessageAtIndex(index);
    if (!messageNode) return false;

    bool success = PlayBuffer(messageNode->Data.buffer, messageNode->Data.size);
    emit playbackFinished(success, success ? "Complete" : "Failed");

    return success;
}

bool CMSController::deleteMessageAtIndex(int index)
{
    if (index < 0 || index >= getQueueSize()) return false;

    if (index == 0) {
        link deleted = deQueue();
        if (deleted) {
            free(deleted->Data.buffer);
            free(deleted);
            return true;
        }
        return false;
    }

    link prev = getMessageAtIndex(index - 1);
    if (!prev || !prev->pNext) return false;

    link toDelete = prev->pNext;
    prev->pNext = toDelete->pNext;

    extern link rear;
    if (toDelete == rear) rear = prev;

    free(toDelete->Data.buffer);
    free(toDelete);

    extern int messageCount;
    messageCount--;

    return true;
}
