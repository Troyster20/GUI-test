#include <QApplication>
#include "GUI/MainWindow.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    app.setApplicationName("CMS Project");
    app.setApplicationVersion("1.0");
    app.setOrganizationName("Kien Matthew Troy");

    MainWindow mainWindow;
    mainWindow.show();

    return app.exec();
}
