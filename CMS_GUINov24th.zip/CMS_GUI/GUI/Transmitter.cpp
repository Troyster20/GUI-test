#include "Transmitter.h"
#include "ui_Transmitter.h"

// ALL Qt includes needed
#include <QMessageBox>
#include <QFileDialog>
#include <QInputDialog>
#include <QDateTime>
#include <QProgressDialog>
#include <QApplication>
#include <QTimer>
#include <QString>
#include <QFile>
#include <QTextStream>

Transmitter::Transmitter(CMSController* controller, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Transmitter),
    m_controller(controller)
{
    ui->setupUi(this);

    connect(m_controller, &CMSController::recordingFinished, this, &Transmitter::onRecordingFinished);
    connect(m_controller, &CMSController::playbackFinished, this, &Transmitter::onPlaybackFinished);
    connect(m_controller, &CMSController::errorOccurred, this, &Transmitter::onErrorOccurred);

    ui->dateTimeLabel->setText(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"));

    if (!m_controller->initializeTransmitter()) {
        QMessageBox::warning(this, "COM Port Warning",
                             "Transmitter COM port initialization failed.\n"
                             "Text messages will still work in simulation mode.");
    }

    updateQueueInfo();
}

Transmitter::~Transmitter()
{
    delete ui;
}

void Transmitter::on_backButton_clicked()
{
    emit backToStart();
}

void Transmitter::on_newTextButton_clicked()
{
    ui->messageTextEdit->clear();
    ui->messageTextEdit->setFocus();
    QMessageBox::information(this, "New Text", "Ready to create new text message");
}

void Transmitter::on_newAudioButton_clicked()
{
    bool ok;
    QString name = QInputDialog::getText(this, "Record Audio",
                                         "Enter a name for this recording:",
                                         QLineEdit::Normal, "", &ok);
    if (!ok || name.isEmpty()) {
        return;
    }

    QProgressDialog* progress = new QProgressDialog(
        "Recording in progress...\n\n"
        "Speak into your microphone now!\n"
        "Recording will last 6 seconds.",
        QString(), 0, 100, this);

    progress->setWindowTitle("Recording Audio");
    progress->setWindowModality(Qt::WindowModal);
    progress->setMinimumDuration(0);
    progress->setCancelButton(nullptr);
    progress->setValue(0);
    progress->show();
    QApplication::processEvents();

    const int recordTime = 6000;
    const int updateInterval = 100;
    int elapsed = 0;

    progress->setValue(5);
    QApplication::processEvents();

    QTimer* timer = new QTimer(this);
    connect(timer, &QTimer::timeout, [&]() {
        elapsed += updateInterval;
        int progressValue = (elapsed * 100) / recordTime;
        if (progressValue > 100) progressValue = 100;
        progress->setValue(progressValue);
        QApplication::processEvents();
    });

    timer->start(updateInterval);

    bool success = m_controller->startRecording(name);

    timer->stop();
    delete timer;
    progress->setValue(100);
    progress->close();
    delete progress;

    if (success) {
        updateQueueInfo();
    }
}

void Transmitter::on_sendButton_clicked()
{
    QString message = ui->messageTextEdit->toPlainText();
    if (message.isEmpty()) {
        QMessageBox::warning(this, "Empty Message", "Please enter a message before sending.");
        return;
    }

    QString recipient = ui->recipientComboBox->currentText();
    bool encrypt = ui->encryptCheckBox->isChecked();
    bool compress = ui->compressCheckBox->isChecked();

    QString header = QString("TO:%1|TIME:%2|ENCRYPT:%3|COMPRESS:%4|SIZE:%5")
                         .arg(recipient)
                         .arg(QDateTime::currentDateTime().toString("yyyyMMdd-hhmmss"))
                         .arg(encrypt ? "Y" : "N")
                         .arg(compress ? "Y" : "N")
                         .arg(message.length());

    QString fullMessage = header + "\n" + message;

    if (m_controller->sendTextMessage(fullMessage)) {
        QString status = QString("✓ Message sent to %1\n\nEncryption: %2\nCompression: %3")
                             .arg(recipient)
                             .arg(encrypt ? "Yes" : "No")
                             .arg(compress ? "Yes" : "No");

        QMessageBox::information(this, "Message Sent", status);

        if (ui->saveToFileCheckBox->isChecked()) {
            on_saveButton_clicked();
        }
    } else {
        QMessageBox::critical(this, "Send Error", "Failed to send message");
    }
}

void Transmitter::on_saveButton_clicked()
{
    QString message = ui->messageTextEdit->toPlainText();
    if (message.isEmpty()) {
        QMessageBox::warning(this, "Empty Message", "No message to save.");
        return;
    }

    QString fileName = QFileDialog::getSaveFileName(this, "Save Message", "", "Text Files (*.txt)");
    if (!fileName.isEmpty()) {
        QFile file(fileName);
        if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            QTextStream out(&file);
            out << "CMS Message\n";
            out << "Time: " << QDateTime::currentDateTime().toString() << "\n";
            out << "To: " << ui->recipientComboBox->currentText() << "\n";
            out << "Message:\n" << message << "\n";
            file.close();
            QMessageBox::information(this, "Success", "Message saved to file.");
        } else {
            QMessageBox::critical(this, "Error", "Could not save file.");
        }
    }
}

void Transmitter::on_playQueueButton_clicked()
{
    m_controller->playCurrentAudio();
}

void Transmitter::on_deleteQueueButton_clicked()
{
    if (m_controller->deleteCurrentAudio()) {
        QMessageBox::information(this, "Success", "Audio message deleted from queue");
        updateQueueInfo();
    } else {
        QMessageBox::warning(this, "Error", "No audio message to delete");
    }
}

void Transmitter::on_manageQueueButton_clicked()
{
    emit showQueueManager();
}

void Transmitter::onRecordingFinished(bool success, const QString& message)
{
    if (success) {
        QMessageBox::information(this, "Recording Complete", message);
        updateQueueInfo();
    } else {
        QMessageBox::critical(this, "Recording Failed", message);
    }
}

void Transmitter::onPlaybackFinished(bool success, const QString& message)
{
    if (success) {
        QMessageBox::information(this, "Playback", message);
    } else {
        QMessageBox::critical(this, "Playback Error", message);
    }
}

void Transmitter::onErrorOccurred(const QString& error)
{
    QMessageBox::critical(this, "Error", error);
}

void Transmitter::updateQueueInfo()
{
    int messageCount = m_controller->getMessageCount();
    QString currentMessage = m_controller->getCurrentMessageName();

    QString queueInfo = QString("Queue: %1 messages - Current: %2")
                            .arg(messageCount)
                            .arg(currentMessage.isEmpty() ? "None" : currentMessage);

    ui->queueInfoLabel->setText(queueInfo);
}
