#include "Settings.h"
#include "ui_Settings.h"
#include <QMessageBox>

Settings::Settings(CMSController* controller, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Settings),
    m_controller(controller)
{
    ui->setupUi(this);
    updateSettingsDisplay();
}

Settings::~Settings()
{
    delete ui;
}

void Settings::on_backButton_clicked()
{
    emit backToStart();
}

void Settings::on_saveButton_clicked()
{
    QString txPort = ui->txComEdit->text();
    QString rxPort = ui->rxComEdit->text();
    QString baudRate = ui->baudRateCombo->currentText();

    bool txSuccess = m_controller->initializeTransmitter(txPort);
    bool rxSuccess = m_controller->initializeReceiver(rxPort);

    QString message = "=== SETTINGS SAVED ===\n\n";
    message += QString("Transmitter Configuration:\n");
    message += QString("• Port: %1 %2\n").arg(txPort).arg(txSuccess ? "[OK]" : "[FAILED]");
    message += QString("\nReceiver Configuration:\n");
    message += QString("• Port: %1 %2\n").arg(rxPort).arg(rxSuccess ? "[OK]" : "[FAILED]");
    message += QString("\nCommunication Parameters:\n");
    message += QString("• Baud Rate: %1 bps\n").arg(baudRate);
    message += QString("• Protocol: Header + Payload\n");
    message += QString("• Data Bits: 8\n");
    message += QString("• Stop Bits: 1\n");
    message += QString("• Parity: None\n\n");

    if (!txSuccess || !rxSuccess) {
        message += "Warning: Port initialization issues detected.\n";
        message += "Check that ports are available and not in use.";
    } else {
        message += "Status: All ports configured successfully.";
    }

    QMessageBox::information(this, "Settings Updated", message);
}

void Settings::on_defaultsButton_clicked()
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Restore Default Settings",
                                  "Restore all settings to default values?\n\n"
                                  "Default Configuration:\n"
                                  "• Transmitter: COM6\n"
                                  "• Receiver: COM7\n"
                                  "• Baud Rate: 460800 bps\n"
                                  "• Error Detection: Enabled\n"
                                  "• Compression: Disabled\n"
                                  "• Auto-save: Enabled\n"
                                  "• Sound Notifications: Enabled",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        ui->txComEdit->setText("COM6");
        ui->rxComEdit->setText("COM7");
        ui->baudRateCombo->setCurrentText("460800");
        ui->errorDetectionCheck->setChecked(true);
        ui->compressionCheck->setChecked(false);
        ui->autoSaveCheck->setChecked(true);
        ui->playSoundCheck->setChecked(true);

        QMessageBox::information(this, "Defaults Restored",
                                 "All settings have been restored to default values.\n\n"
                                 "Configuration:\n"
                                 "• Transmitter: COM6\n"
                                 "• Receiver: COM7\n"
                                 "• Baud Rate: 460800 bps");
    }
}

void Settings::updateSettingsDisplay()
{
    ui->txComEdit->setText("COM6");
    ui->rxComEdit->setText("COM7");

    bool has460800 = false;
    for (int i = 0; i < ui->baudRateCombo->count(); i++) {
        if (ui->baudRateCombo->itemText(i) == "460800") {
            has460800 = true;
            break;
        }
    }
    if (!has460800) {
        ui->baudRateCombo->addItem("460800");
    }

    ui->baudRateCombo->setCurrentText("460800");
    ui->errorDetectionCheck->setChecked(true);
    ui->compressionCheck->setChecked(false);
    ui->autoSaveCheck->setChecked(true);
    ui->playSoundCheck->setChecked(true);
}
