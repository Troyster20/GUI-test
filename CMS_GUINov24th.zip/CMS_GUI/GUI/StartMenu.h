#ifndef STARTMENU_H
#define STARTMENU_H

#include <QWidget>
#include "CMSController.h"

namespace Ui {
class StartMenu;
}

class StartMenu : public QWidget
{
    Q_OBJECT

public:
    explicit StartMenu(CMSController* controller, QWidget *parent = nullptr);
    ~StartMenu();

signals:
    void showTransmitter();
    void showReceiver();
    void showTesting();
    void showPhonebook();
    void showSettings();
    void quitApplication();

private slots:
    void on_transmitButton_clicked();
    void on_receiveButton_clicked();
    void on_testingButton_clicked();
    void on_phonebookButton_clicked();
    void on_settingsButton_clicked();
    void on_quitButton_clicked();

private:
    Ui::StartMenu *ui;
    CMSController* m_controller;
};

#endif // STARTMENU_H
