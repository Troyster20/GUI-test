#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>

class StartMenu;
class Transmitter;
class Receiver;
class Testing;
class Phonebook;
class Settings;
class CMSController;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

public slots:
    void showStartMenu();
    void showTransmitter();
    void showReceiver();
    void showTesting();
    void showPhonebook();
    void showSettings();
    void quitApplication();

private:
    void setupUI();
    void connectSignals();

    QStackedWidget *stackedWidget;
    StartMenu *startMenu;
    Transmitter *transmitter;
    Receiver *receiver;
    Testing *testing;
    Phonebook *phonebook;
    Settings *settings;
    CMSController *controller;
};

#endif
