#ifndef TRANSMITTER_H
#define TRANSMITTER_H

#include <QWidget>
#include <QString>
#include "CMSController.h"

namespace Ui {
class Transmitter;
}

class Transmitter : public QWidget
{
    Q_OBJECT

public:
    explicit Transmitter(CMSController* controller, QWidget *parent = nullptr);
    ~Transmitter();

signals:
    void backToStart();
    void showQueueManager();

private slots:
    void on_backButton_clicked();
    void on_newTextButton_clicked();
    void on_newAudioButton_clicked();
    void on_sendButton_clicked();
    void on_saveButton_clicked();
    void on_playQueueButton_clicked();
    void on_deleteQueueButton_clicked();
    void on_manageQueueButton_clicked();

    void onRecordingFinished(bool success, const QString& message);
    void onPlaybackFinished(bool success, const QString& message);
    void onErrorOccurred(const QString& error);

private:
    void updateQueueInfo();

    Ui::Transmitter *ui;
    CMSController* m_controller;
};

#endif // TRANSMITTER_H
