#include "CMSController.h"
#include <QDebug>
#include <QMessageBox>
#include <QInputDialog>
#include <QDateTime>
#include <QThread>
#include <QProgressDialog>
#include <QApplication>

#include "../src/sound.h"
#include "../src/audioQueue.h"
#include "../src/RS232Comm.h"

extern short iBigBuf[];
extern long lBigBufSize;
extern int nComRate;
extern int nComBits;
extern COMMTIMEOUTS timeout;

CMSController::CMSController(QObject *parent)
    : QObject(parent)
    , systemsInitialized(false)
    , m_hComTx(INVALID_HANDLE_VALUE)
    , m_hComRx(INVALID_HANDLE_VALUE)
{
    initializeSystems();
}

CMSController::~CMSController()
{
    cleanupSystems();
}

void CMSController::initializeSystems()
{
    if (!systemsInitialized) {
        qDebug() << "=== Initializing CMS Systems ===";
        qDebug() << "Baud rate: 460800 bps";

        initQueue();
        qDebug() << "Message queue initialized";

        if (InitializePlayback()) {
            qDebug() << "Audio playback initialized successfully";
        } else {
            qDebug() << "WARNING: Playback initialization failed";
        }

        if (InitializeRecording()) {
            qDebug() << "Audio recording initialized successfully";
        } else {
            qDebug() << "WARNING: Recording initialization failed";
        }

        systemsInitialized = true;
        qDebug() << "CMS Systems ready";
    }
}

void CMSController::cleanupSystems()
{
    if (systemsInitialized) {
        qDebug() << "=== Shutting down CMS Systems ===";

        ClosePlayback();
        CloseRecording();
        clearQueue();

        if (m_hComTx != INVALID_HANDLE_VALUE) {
            CloseHandle(m_hComTx);
            m_hComTx = INVALID_HANDLE_VALUE;
        }
        if (m_hComRx != INVALID_HANDLE_VALUE) {
            CloseHandle(m_hComRx);
            m_hComRx = INVALID_HANDLE_VALUE;
        }

        systemsInitialized = false;
        qDebug() << "CMS Systems shutdown complete";
    }
}

bool CMSController::startRecording(const QString& filename)
{
    if (!systemsInitialized) {
        emit recordingFinished(false, "System not initialized");
        return false;
    }

    QByteArray ba = filename.toLocal8Bit();
    const char* name = ba.constData();

    qDebug() << "Starting audio recording:" << filename;

    bool success = RecordBuffer(iBigBuf, lBigBufSize);

    if (success) {
        qDebug() << "Recording completed successfully";
        enqueue(iBigBuf, lBigBufSize, name);
        qDebug() << "Audio message added to queue";
        emit recordingFinished(true, QString("Recording '%1' completed successfully!").arg(filename));
    } else {
        qDebug() << "Recording failed";
        QString errorMsg = "RECORDING FAILED\n\n"
                           "Possible causes:\n"
                           "• Microphone not accessible\n"
                           "• Audio driver issue\n"
                           "• Microphone permissions denied\n\n"
                           "Troubleshooting:\n"
                           "1. Open Windows Sound Settings\n"
                           "2. Go to Recording tab\n"
                           "3. Ensure microphone is ENABLED and set as DEFAULT\n"
                           "4. Test microphone in Windows settings\n"
                           "5. Check Windows Privacy Settings → Microphone";

        emit recordingFinished(false, errorMsg);
        emit errorOccurred(errorMsg);
    }

    return success;
}

bool CMSController::playCurrentAudio()
{
    if (!systemsInitialized || isQueueEmpty()) {
        emit playbackFinished(false, "No audio message to play");
        return false;
    }

    link frontNode = peekQueue();
    if (!frontNode) {
        emit playbackFinished(false, "Queue error");
        return false;
    }

    QString messageName = QString::fromLocal8Bit(frontNode->Data.filename);
    qDebug() << "Playing audio message:" << messageName;

    bool success = PlayBuffer(frontNode->Data.buffer, frontNode->Data.size);

    if (success) {
        emit playbackFinished(true, "Playback completed successfully");
    } else {
        emit playbackFinished(false, "Playback failed - check audio output device");
    }

    return success;
}

bool CMSController::saveCurrentAudio(const QString& filename)
{
    if (!systemsInitialized || isQueueEmpty()) return false;

    link frontNode = peekQueue();
    if (!frontNode) return false;

    QByteArray ba = filename.toLocal8Bit();
    saveAudio(frontNode->Data.buffer, frontNode->Data.size, ba.constData());

    return true;
}

bool CMSController::deleteCurrentAudio()
{
    if (!systemsInitialized || isQueueEmpty()) return false;

    link deleted = deQueue();
    if (deleted) {
        free(deleted->Data.buffer);
        free(deleted);
        return true;
    }
    return false;
}

bool CMSController::initializeTransmitter(const QString& portName)
{
    if (!systemsInitialized) return false;

    if (m_hComTx != INVALID_HANDLE_VALUE) {
        CloseHandle(m_hComTx);
        m_hComTx = INVALID_HANDLE_VALUE;
    }

    std::wstring port = portName.toStdWString();
    m_hComTx = setupComPort(port.c_str(), nComRate, nComBits, timeout);

    bool success = (m_hComTx != INVALID_HANDLE_VALUE);

    if (success) {
        qDebug() << "Transmitter initialized on" << portName << "at 460800 baud";
    } else {
        qDebug() << "Failed to open transmitter port" << portName;
    }

    return success;
}

bool CMSController::initializeReceiver(const QString& portName)
{
    if (!systemsInitialized) return false;

    if (m_hComRx != INVALID_HANDLE_VALUE) {
        CloseHandle(m_hComRx);
        m_hComRx = INVALID_HANDLE_VALUE;
    }

    std::wstring port = portName.toStdWString();
    m_hComRx = setupComPort(port.c_str(), nComRate, nComBits, timeout);

    bool success = (m_hComRx != INVALID_HANDLE_VALUE);

    if (success) {
        qDebug() << "Receiver initialized on" << portName << "at 460800 baud";
    } else {
        qDebug() << "Failed to open receiver port" << portName;
    }

    return success;
}

bool CMSController::sendTextMessage(const QString& message)
{
    if (!systemsInitialized || message.isEmpty()) return false;

    if (m_hComTx == INVALID_HANDLE_VALUE) {
        if (!initializeTransmitter()) return false;
    }

    QByteArray ba = message.toLocal8Bit();
    outputToPort(&m_hComTx, ba.constData(), ba.length() + 1);

    emit messageSent(true, "Text message transmitted successfully");
    return true;
}

QString CMSController::receiveTextMessage()
{
    if (!systemsInitialized) return QString();

    if (m_hComRx == INVALID_HANDLE_VALUE) {
        if (!initializeReceiver()) {
            qDebug() << "Cannot initialize receiver for text reception";
            return QString();
        }
    }

    char buffer[BUFSIZE];
    memset(buffer, 0, BUFSIZE);

    qDebug() << "Waiting to receive text message...";
    DWORD bytesRead = inputFromPort(&m_hComRx, buffer, BUFSIZE - 1);

    if (bytesRead > 0) {
        buffer[bytesRead] = '\0';
        QString msg = QString::fromLocal8Bit(buffer);
        qDebug() << "Text message received:" << bytesRead << "bytes";
        emit messageReceived(msg);
        return msg;
    }

    qDebug() << "No text data received";
    return QString();
}

int CMSController::getMessageCount() const
{
    extern int messageCount;
    return messageCount;
}

QString CMSController::getCurrentMessageName() const
{
    if (isQueueEmpty()) return QString();

    link frontNode = peekQueue();
    return frontNode ? QString::fromLocal8Bit(frontNode->Data.filename) : QString();
}

bool CMSController::sendAudioMessage(int queueIndex)
{
    qDebug() << "=== Audio Transmission Protocol ===";
    qDebug() << "Sending message at queue index:" << queueIndex;

    if (!systemsInitialized) {
        qDebug() << "ERROR: System not initialized";
        QMessageBox::critical(nullptr, "Error", "System not initialized");
        return false;
    }

    link messageNode = getMessageAtIndex(queueIndex);
    if (!messageNode) {
        qDebug() << "ERROR: No message at index" << queueIndex;
        QMessageBox::critical(nullptr, "Error", "Invalid queue index");
        return false;
    }

    if (m_hComTx == INVALID_HANDLE_VALUE) {
        qDebug() << "Transmitter not initialized, opening port...";
        if (!initializeTransmitter()) {
            QMessageBox::critical(nullptr, "Error",
                                  "Cannot open transmitter COM port.\n\n"
                                  "Check:\n"
                                  "• COM port is available\n"
                                  "• No other program is using it\n"
                                  "• Port settings are correct");
            return false;
        }
    }

    QString filename = QString::fromLocal8Bit(messageNode->Data.filename);
    long numSamples = messageNode->Data.size;
    long payloadSize = numSamples * sizeof(short);

    qDebug() << "Transmitting audio:" << filename;
    qDebug() << "Payload size:" << payloadSize << "bytes (" << payloadSize / 1024 << "KB)";
    qDebug() << "Estimated transmission time: ~" << (payloadSize * 10) / 460800 << "seconds";

    // Prepare transmission header
    Header txHeader;
    txHeader.sid = 1;
    txHeader.rid = 2;
    txHeader.priority = 0;
    txHeader.seqNum = 0;
    txHeader.payloadSize = payloadSize;
    txHeader.payLoadType = 'A';  // Audio
    txHeader.encryption = 0;     // No encryption
    txHeader.compression = 0;    // No compression

    QProgressDialog* progress = new QProgressDialog(
        QString("Transmitting audio message: %1\n\n"
                "Size: %2 KB\n"
                "Protocol: Header + Payload\n"
                "Baud rate: 460800 bps\n\n"
                "Please wait...")
            .arg(filename)
            .arg(payloadSize / 1024),
        QString(), 0, 100, nullptr);

    progress->setWindowTitle("Transmitting Audio");
    progress->setMinimumDuration(0);
    progress->setCancelButton(nullptr);
    progress->setValue(20);
    progress->show();
    QApplication::processEvents();

    // Transmit header + payload
    transmit(&txHeader, (void*)messageNode->Data.buffer, &m_hComTx);

    progress->setValue(100);
    QApplication::processEvents();
    QThread::msleep(200);
    progress->close();
    delete progress;

    qDebug() << "Audio transmission completed successfully";

    QMessageBox::information(nullptr, "Transmission Complete",
                             QString("Audio message transmitted successfully!\n\n"
                                     "Filename: %1\n"
                                     "Size: %2 KB\n"
                                     "Samples: %3")
                                 .arg(filename)
                                 .arg(payloadSize / 1024)
                                 .arg(numSamples));

    emit messageSent(true, "Audio transmitted");
    return true;
}

bool CMSController::receiveAudioMessage()
{
    qDebug() << "=== Audio Reception Protocol ===";

    if (!systemsInitialized) {
        QMessageBox::critical(nullptr, "Error", "System not initialized");
        return false;
    }

    if (m_hComRx == INVALID_HANDLE_VALUE) {
        qDebug() << "Receiver not initialized, opening port...";
        if (!initializeReceiver()) {
            QMessageBox::critical(nullptr, "Error",
                                  "Cannot open receiver COM port.\n\n"
                                  "Check:\n"
                                  "• COM port is available\n"
                                  "• No other program is using it\n"
                                  "• Cable is properly connected");
            return false;
        }
    }

    qDebug() << "Waiting for incoming audio transmission...";

    QProgressDialog* progress = new QProgressDialog(
        "Waiting for audio transmission...\n\n"
        "Protocol: Header + Payload\n"
        "Baud rate: 460800 bps\n\n"
        "Receiver is ready.\n"
        "Start transmission from transmitter NOW!",
        QString(), 0, 100, nullptr);

    progress->setWindowTitle("Receiving Audio");
    progress->setMinimumDuration(0);
    progress->setValue(10);
    progress->show();
    QApplication::processEvents();

    Header rxHeader;
    memset(&rxHeader, 0, sizeof(Header));
    void* rxPayload = NULL;

    // Attempt to receive header + payload
    qDebug() << "Calling receive function...";
    DWORD bytesRead = receive(&rxHeader, &rxPayload, &m_hComRx);

    progress->setValue(90);
    QApplication::processEvents();

    qDebug() << "Receive function returned, bytes read:" << bytesRead;
    qDebug() << "Header payload size:" << rxHeader.payloadSize;
    qDebug() << "Header payload type:" << rxHeader.payLoadType;

    progress->setValue(100);
    QApplication::processEvents();
    QThread::msleep(200);
    progress->close();
    delete progress;

    if (bytesRead == 0 || rxPayload == NULL) {
        QString errorMsg = "No data received\n\n"
                           "Possible causes:\n"
                           "• No transmission sent\n"
                           "• Cable not connected\n"
                           "• COM port timeout\n"
                           "• Baud rate mismatch\n\n"
                           "Make sure transmitter sends AFTER\n"
                           "receiver is waiting!";

        qDebug() << "Reception failed - no data received";
        QMessageBox::critical(nullptr, "Reception Failed", errorMsg);
        return false;
    }

    if (rxHeader.payLoadType == 'A') {
        // Audio message received
        short* audioBuffer = (short*)rxPayload;
        long numSamples = rxHeader.payloadSize / sizeof(short);

        QString audioName = QString("Received_%1").arg(QDateTime::currentDateTime().toString("hhmmss"));

        qDebug() << "Audio message received successfully";
        qDebug() << "Samples:" << numSamples;
        qDebug() << "Adding to queue as:" << audioName;

        // Add to queue
        enqueue(audioBuffer, numSamples, audioName.toLocal8Bit().constData());

        QString msg = QString("Audio message received successfully!\n\n"
                              "Size: %1 KB\n"
                              "Duration: %2 seconds\n"
                              "Samples: %3\n\n"
                              "Message added to queue.\n"
                              "Go to Transmitter screen to play it.")
                          .arg(rxHeader.payloadSize / 1024)
                          .arg((double)numSamples / 8000.0, 0, 'f', 1)
                          .arg(numSamples);

        QMessageBox::information(nullptr, "Audio Received", msg);
        emit messageReceived(msg);

        free(rxPayload);
        return true;

    } else if (rxHeader.payLoadType == 'T') {
        // Text message
        char* textData = (char*)rxPayload;
        qDebug() << "Text message received:" << textData;
        free(rxPayload);
        QMessageBox::information(nullptr, "Text Received", QString("Text: %1").arg(textData));
        return true;

    } else {
        qDebug() << "Unknown message type received:" << rxHeader.payLoadType;
        free(rxPayload);
        QMessageBox::warning(nullptr, "Warning",
                             QString("Received unknown message type: %1").arg(rxHeader.payLoadType));
        return false;
    }
}

QStringList CMSController::getQueueList() const
{
    QStringList list;
    int count = getQueueSize();
    for (int i = 0; i < count; i++) {
        link node = getMessageAtIndex(i);
        if (node) {
            list.append(QString("[%1] %2").arg(i).arg(QString::fromLocal8Bit(node->Data.filename)));
        }
    }
    return list;
}

bool CMSController::playMessageAtIndex(int index)
{
    link messageNode = getMessageAtIndex(index);
    if (!messageNode) return false;

    bool success = PlayBuffer(messageNode->Data.buffer, messageNode->Data.size);
    emit playbackFinished(success, success ? "Playback complete" : "Playback failed");

    return success;
}

bool CMSController::deleteMessageAtIndex(int index)
{
    if (index < 0 || index >= getQueueSize()) return false;

    if (index == 0) {
        link deleted = deQueue();
        if (deleted) {
            free(deleted->Data.buffer);
            free(deleted);
            return true;
        }
        return false;
    }

    link prev = getMessageAtIndex(index - 1);
    if (!prev || !prev->pNext) return false;

    link toDelete = prev->pNext;
    prev->pNext = toDelete->pNext;

    extern link rear;
    if (toDelete == rear) rear = prev;

    free(toDelete->Data.buffer);
    free(toDelete);

    extern int messageCount;
    messageCount--;

    return true;
}
