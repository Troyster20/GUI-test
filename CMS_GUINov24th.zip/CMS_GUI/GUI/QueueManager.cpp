#include "QueueManager.h"
#include "ui_QueueManager.h"
#include <QMessageBox>
#include <QDebug>

QueueManager::QueueManager(CMSController* controller, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::QueueManager),
    m_controller(controller)
{
    ui->setupUi(this);

    // Connect controller signals
    connect(m_controller, &CMSController::playbackFinished, this, &QueueManager::onPlaybackFinished);
    connect(m_controller, &CMSController::messageSent, this, &QueueManager::onMessageSent);

    // Refresh the queue display
    refreshQueueDisplay();
}

QueueManager::~QueueManager()
{
    delete ui;
}

void QueueManager::refreshQueueDisplay()
{
    // Clear the list
    ui->queueListWidget->clear();

    // Get the queue list from controller
    QStringList queueList = m_controller->getQueueList();

    // Update status label
    int messageCount = m_controller->getMessageCount();
    ui->queueStatusLabel->setText(QString("Queue: %1 message%2")
                                      .arg(messageCount)
                                      .arg(messageCount == 1 ? "" : "s"));

    // Add items to list widget
    for (const QString& item : queueList) {
        ui->queueListWidget->addItem(item);
    }

    // Select first item if available
    if (ui->queueListWidget->count() > 0) {
        ui->queueListWidget->setCurrentRow(0);
    }

    qDebug() << "Queue display refreshed:" << messageCount << "messages";
}

int QueueManager::getSelectedIndex()
{
    int row = ui->queueListWidget->currentRow();
    if (row < 0) {
        QMessageBox::warning(this, "No Selection", "Please select a message from the list.");
        return -1;
    }
    return row;
}

void QueueManager::on_backButton_clicked()
{
    emit backToTransmitter();
}

void QueueManager::on_playButton_clicked()
{
    int index = getSelectedIndex();
    if (index < 0) return;

    qDebug() << "Playing message at index:" << index;
    m_controller->playMessageAtIndex(index);
}

void QueueManager::on_sendButton_clicked()
{
    int index = getSelectedIndex();
    if (index < 0) return;

    qDebug() << "Sending message at index:" << index;

    QMessageBox::StandardButton reply = QMessageBox::question(
        this,
        "Send Audio Message",
        "Send the selected audio message over COM port?",
        QMessageBox::Yes | QMessageBox::No
        );

    if (reply == QMessageBox::Yes) {
        m_controller->sendAudioMessage(index);
    }
}

void QueueManager::on_deleteButton_clicked()
{
    int index = getSelectedIndex();
    if (index < 0) return;

    QMessageBox::StandardButton reply = QMessageBox::question(
        this,
        "Delete Message",
        "Are you sure you want to delete the selected message?",
        QMessageBox::Yes | QMessageBox::No
        );

    if (reply == QMessageBox::Yes) {
        if (m_controller->deleteMessageAtIndex(index)) {
            QMessageBox::information(this, "Success", "Message deleted successfully");
            refreshQueueDisplay();
        } else {
            QMessageBox::critical(this, "Error", "Failed to delete message");
        }
    }
}

void QueueManager::on_refreshButton_clicked()
{
    refreshQueueDisplay();
}

void QueueManager::onPlaybackFinished(bool success, const QString& message)
{
    if (success) {
        QMessageBox::information(this, "Playback Complete", message);
    } else {
        QMessageBox::critical(this, "Playback Failed", message);
    }
}

void QueueManager::onMessageSent(bool success, const QString& message)
{
    if (success) {
        QMessageBox::information(this, "Message Sent", message);
    } else {
        QMessageBox::critical(this, "Send Failed", message);
    }
}
