#ifndef CMSCONTROLLER_H
#define CMSCONTROLLER_H

#include <QObject>
#include <QString>

#ifdef _WIN32
#include <windows.h>
#endif

// Include the header - don't forward declare
#include "../src/RS232Comm.h"

class CMSController : public QObject
{
    Q_OBJECT

public:
    explicit CMSController(QObject *parent = nullptr);
    ~CMSController();

    Q_INVOKABLE bool startRecording(const QString& filename);
    Q_INVOKABLE bool playCurrentAudio();
    Q_INVOKABLE bool saveCurrentAudio(const QString& filename);
    Q_INVOKABLE bool deleteCurrentAudio();

    Q_INVOKABLE bool initializeTransmitter(const QString& portName = "COM6");
    Q_INVOKABLE bool initializeReceiver(const QString& portName = "COM7");
    Q_INVOKABLE bool sendTextMessage(const QString& message);
    Q_INVOKABLE QString receiveTextMessage();

    Q_INVOKABLE int getMessageCount() const;
    Q_INVOKABLE QString getCurrentMessageName() const;

    Q_INVOKABLE void initializeSystems();
    Q_INVOKABLE void cleanupSystems();

    Q_INVOKABLE bool sendAudioMessage(int queueIndex);
    Q_INVOKABLE bool receiveAudioMessage();

    Q_INVOKABLE QStringList getQueueList() const;
    Q_INVOKABLE bool playMessageAtIndex(int index);
    Q_INVOKABLE bool deleteMessageAtIndex(int index);

signals:
    void recordingFinished(bool success, const QString& message);
    void playbackFinished(bool success, const QString& message);
    void messageSent(bool success, const QString& message);
    void messageReceived(const QString& message);
    void errorOccurred(const QString& error);

private:
    bool systemsInitialized;
    HANDLE m_hComTx;
    HANDLE m_hComRx;
};

#endif
