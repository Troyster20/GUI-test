#include "audioQueue.h"
#include <string.h>

link front = NULL;
link rear = NULL;
int messageCount = 0;

void initQueue(){
    front = rear = NULL;
    messageCount = 0;
}

int isQueueEmpty(){
    return (front == NULL);
}

void enqueue(short* buf, long size, const char* name){
    link newNode = (link)malloc(sizeof(Node));
    if (!newNode) return;

    newNode->Data.buffer = (short*)malloc(size * sizeof(short));
    if (!newNode->Data.buffer) {
        free(newNode);
        return;
    }

    memcpy(newNode->Data.buffer, buf, size * sizeof(short));
    newNode->Data.size = size;

    // Use standard strncpy instead of strncpy_s
    strncpy(newNode->Data.filename, name, MAX_FILENAME - 1);
    newNode->Data.filename[MAX_FILENAME - 1] = '\0';

    newNode->pNext = NULL;

    if (isQueueEmpty()) {
        front = rear = newNode;
    } else {
        rear->pNext = newNode;
        rear = newNode;
    }
    messageCount++;
}

link deQueue(){
    if (isQueueEmpty()) return NULL;

    link temp = front;
    front = front->pNext;
    if (front == NULL) {
        rear = NULL;
    }
    messageCount--;
    return temp;
}

void clearQueue(){
    while (!isQueueEmpty()) {
        link temp = deQueue();
        if (temp) {
            free(temp->Data.buffer);
            free(temp);
        }
    }
}

link peekQueue() {
    return front;
}

int getQueueSize() {
    return messageCount;
}

link getMessageAtIndex(int index) {
    if (index < 0 || index >= messageCount) return NULL;

    link current = front;
    for (int i = 0; i < index && current; i++) {
        current = current->pNext;
    }
    return current;
}
