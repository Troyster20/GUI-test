#ifndef COMPATIBILITY_H
#define COMPATIBILITY_H

// Fix Windows and Qt compatibility issues

// Disable problematic Windows macros that conflict with Qt
#define NOGDI
#define NOUSER
#define NOKERNEL
#define NOSOUND
#include <windows.h>
#undef NOGDI
#undef NOUSER
#undef NOKERNEL
#undef NOSOUND

// Fix function declarations for C++ compatibility
#ifdef __cplusplus
extern "C" {
#endif

// Declare your existing functions here if needed

#ifdef __cplusplus
}
#endif

#endif // COMPATIBILITY_H


