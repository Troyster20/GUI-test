#include "RS232Comm.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int nComRate = 460800;
int nComBits = 8;
COMMTIMEOUTS timeout = { 0 };

// GROUP MATE'S WORKING TRANSMIT
void transmit(Header* txHeader, void* txPayload, HANDLE* hCom) {
    // Send header
    outputToPort(hCom, txHeader, sizeof(Header));
    // Send payload
    outputToPort(hCom, txPayload, txHeader->payloadSize);
    Sleep(500);
    purgePort(hCom);
}

// GROUP MATE'S WORKING RECEIVE
DWORD receive(Header* rxHeader, void** rxPayload, HANDLE* hCom) {
    DWORD bytesRead;

    // Read header
    inputFromPort(hCom, rxHeader, sizeof(Header));

    // Allocate payload
    *rxPayload = malloc(rxHeader->payloadSize);
    if (*rxPayload == NULL) {
        return 0;
    }

    // Read payload
    bytesRead = inputFromPort(hCom, *rxPayload, rxHeader->payloadSize);
    purgePort(hCom);

    return bytesRead;
}

void purgePort(HANDLE* hCom) {
    PurgeComm(*hCom, PURGE_RXABORT | PURGE_RXCLEAR | PURGE_TXABORT | PURGE_TXCLEAR);
}

void outputToPort(HANDLE* hCom, LPCVOID buf, DWORD szBuf) {
    DWORD written;
    WriteFile(*hCom, buf, szBuf, &written, NULL);
}

DWORD inputFromPort(HANDLE* hCom, LPVOID buf, DWORD szBuf) {
    DWORD bytesRead;
    ReadFile(*hCom, buf, szBuf, &bytesRead, NULL);
    return bytesRead;
}

HANDLE setupComPort(const wchar_t* portName, int nComRate, int nComBits, COMMTIMEOUTS timeout) {
    HANDLE hCom = CreateFileW(portName, GENERIC_READ | GENERIC_WRITE, 0, NULL,
                              OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

    if (hCom == INVALID_HANDLE_VALUE) {
        return hCom;
    }

    DCB dcb = {0};
    dcb.DCBlength = sizeof(dcb);
    GetCommState(hCom, &dcb);
    dcb.BaudRate = nComRate;
    dcb.ByteSize = (BYTE)nComBits;
    dcb.Parity = 0;
    dcb.StopBits = ONESTOPBIT;
    SetCommState(hCom, &dcb);

    COMMTIMEOUTS timeouts = {0};
    timeouts.ReadIntervalTimeout = 500;
    timeouts.ReadTotalTimeoutMultiplier = 1;
    timeouts.ReadTotalTimeoutConstant = 5000;
    SetCommTimeouts(hCom, &timeouts);

    PurgeComm(hCom, PURGE_RXABORT | PURGE_RXCLEAR | PURGE_TXABORT | PURGE_TXCLEAR);

    return hCom;
}
