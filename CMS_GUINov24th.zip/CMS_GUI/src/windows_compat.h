#ifndef WINDOWS_COMPAT_H
#define WINDOWS_COMPAT_H

// Fix Windows header conflicts with Qt
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX  // Prevent min/max macro conflicts

#include <windows.h>
#include <mmsystem.h>

// Restore any definitions that might be needed
#undef WIN32_LEAN_AND_MEAN

#endif // WINDOWS_COMPAT_H
