/*
===================================================== SECTION HEADER =====================================================

Program Name:   EECE72405-25F
Author:			KIEN MACARTNEY
Date:           OCT 30 2025
Comments:		Projects III - Coded Messaging System

                Receiver header file

==========================================================================================================================
*/
#ifndef RX_H
#define RX_H

#ifdef _WIN32
#include <windows.h>
#endif

void playText(HANDLE* hComRx);
void Rx_goBack();
void receiverLoop(HANDLE* hComRx);

#endif // RX_H
