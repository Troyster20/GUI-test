#include "Settings.h"
#include "ui_Settings.h"
#include <QMessageBox>

Settings::Settings(CMSController* controller, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Settings),
    m_controller(controller)
{
    ui->setupUi(this);
    updateSettingsDisplay();
}

Settings::~Settings()
{
    delete ui;
}

void Settings::on_backButton_clicked()
{
    emit backToStart();
}

void Settings::on_saveButton_clicked()
{
    QString txPort = ui->txComEdit->text();
    QString rxPort = ui->rxComEdit->text();
    int baudRate = ui->baudRateCombo->currentText().toInt();

    m_controller->setTxPort(txPort);
    m_controller->setRxPort(rxPort);
    m_controller->setBaudRate(baudRate);

    bool txSuccess = m_controller->initializeTransmitter(txPort);
    bool rxSuccess = m_controller->initializeReceiver(rxPort);

    m_controller->saveConfigToFile();

    QString message = "Settings saved successfully.\n";

    if (!txSuccess) {
        message += "Warning: Transmitter port " + txPort + " initialization failed.\n";
    }
    if (!rxSuccess) {
        message += "Warning: Receiver port " + rxPort + " initialization failed.\n";
    }

    message += "Note: Some changes may require restarting the application.";

    QMessageBox::information(this, "Settings", message);
}

void Settings::on_defaultsButton_clicked()
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Restore Defaults",
                                  "Are you sure you want to restore all settings to defaults?",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        ui->txComEdit->setText("COM6");
        ui->rxComEdit->setText("COM7");
        ui->baudRateCombo->setCurrentText("9600");
        ui->errorDetectionCheck->setChecked(true);
        ui->compressionCheck->setChecked(false);
        ui->autoSaveCheck->setChecked(true);

        QMessageBox::information(this, "Defaults Restored",
                                 "All settings have been restored to default values.\n"
                                 "Transmitter: COM6\n"
                                 "Receiver: COM7");
    }
}

void Settings::updateSettingsDisplay()
{
    ui->txComEdit->setText(m_controller->getTxPort());
    ui->rxComEdit->setText(m_controller->getRxPort());
    ui->baudRateCombo->setCurrentText(QString::number(m_controller->getBaudRate()));
    ui->errorDetectionCheck->setChecked(true);
    ui->compressionCheck->setChecked(false);
    ui->autoSaveCheck->setChecked(true);
}
