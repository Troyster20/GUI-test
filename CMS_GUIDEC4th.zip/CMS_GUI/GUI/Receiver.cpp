#include "Receiver.h"
#include "ui_Receiver.h"
#include <QMessageBox>
#include <QDateTime>

Receiver::Receiver(CMSController* controller, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Receiver),
    m_controller(controller),
    m_sid(0),
    m_rid(0),
    m_priority(0),
    m_isEncrypted(false),
    m_compressionType(0),
    m_payloadSize(0)
{
    ui->setupUi(this);

    connect(m_controller, &CMSController::messageReceived, this, &Receiver::onMessageReceived);
    connect(m_controller, &CMSController::playbackFinished, this, &Receiver::onPlaybackFinished);
    connect(m_controller, &CMSController::errorOccurred, this, &Receiver::onErrorOccurred);

    if (!m_controller->initializeReceiver()) {
        QMessageBox::warning(this, "COM Port Warning",
                             "Receiver COM port init failed");
    }
}

Receiver::~Receiver()
{
    delete ui;
}

void Receiver::on_backButton_clicked()
{
    emit backToStart();
}

void Receiver::on_playTextButton_clicked()
{
    QString message = m_controller->receiveTextMessage();
    if (!message.isEmpty()) {
        // Check if message has header
        if (message.contains('|') && message.contains('\n')) {
            int headerEnd = message.indexOf('\n');
            QString header = message.left(headerEnd);
            QString messageBody = message.mid(headerEnd + 1);

            parseMessageHeader(header);
            ui->receivedTextEdit->setPlainText(messageBody);
        } else {
            // No header
            ui->receivedTextEdit->setPlainText(message);
            m_currentSender = "Unknown";
            m_messageTime = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
        }

        ui->senderLabel->setText(QString("From SID: %1 → RID: %2").arg(m_sid).arg(m_rid));
        ui->timeLabel->setText("Time: " + m_messageTime);
        ui->priorityLabel->setText(QString("Priority: %1").arg(m_priority));

        QString encText = m_isEncrypted ? "XOR" : "None";
        ui->encryptionLabel->setText("Encryption: " + encText);

        QString compText = m_compressionType == 1 ? "Huffman" :
                               m_compressionType == 2 ? "RLE" : "None";
        ui->compressionLabel->setText("Compression: " + compText);

        ui->sizeLabel->setText(QString("Size: %1 bytes").arg(m_payloadSize));

        QMessageBox::information(this, "Text Message", "Text message received and displayed");
    } else {
        QMessageBox::information(this, "No Message", "No message received");
    }
}

void Receiver::on_playAudioButton_clicked()
{
    if (m_controller->receiveAudioMessage()) {
        QMessageBox::information(this, "Audio Received", "Audio message received, added to queue");

        if (m_controller->playCurrentAudio()) {
            QMessageBox::information(this, "Playing", "Playing received audio");
        }
    } else {
        QMessageBox::warning(this, "No Audio", "No audio message received");
    }
}

void Receiver::on_viewHeaderButton_clicked()
{
    QString headerInfo = QString(
                             "=== MESSAGE HEADER ===\n\n"
                             "Sender ID (SID): %1\n"
                             "Receiver ID (RID): %2\n"
                             "Priority: %3\n"
                             "Timestamp: %4\n\n"
                             "Encryption: %5\n"
                             "Compression: %6\n"
                             "Payload Size: %7 bytes\n\n"
                             "Queue Status: %8 messages")
                             .arg(m_sid)
                             .arg(m_rid)
                             .arg(m_priority)
                             .arg(m_messageTime)
                             .arg(m_isEncrypted ? "XOR" : "None")
                             .arg(m_compressionType == 1 ? "Huffman" : m_compressionType == 2 ? "RLE" : "None")
                             .arg(m_payloadSize)
                             .arg(m_controller->getMessageCount());

    QMessageBox::information(this, "Message Header Details", headerInfo);
}

void Receiver::on_checkErrorsButton_clicked()
{
    QString message = ui->receivedTextEdit->toPlainText();
    if (message.isEmpty()) {
        QMessageBox::information(this, "Error Check", "No message to check");
        return;
    }

    bool hasErrors = false;
    QString errorReport = "=== ERROR CHECK RESULTS ===\n\n";

    if (message.length() < 1) {
        hasErrors = true;
        errorReport += "❌ Message too short\n";
    }

    if (message.contains("�") || message.contains("??")) {
        hasErrors = true;
        errorReport += "❌ Character encoding errors detected\n";
    }

    if (!hasErrors) {
        errorReport += "✓ No errors detected\n";
        errorReport += "✓ Message integrity: OK\n";
        errorReport += "✓ Transmission quality: Good\n\n";
        errorReport += QString("Message stats:\n- Length: %1 chars\n- SID: %2\n- RID: %3\n- Priority: %4")
                           .arg(message.length()).arg(m_sid).arg(m_rid).arg(m_priority);
    } else {
        errorReport += "\n⚠ Message may be corrupted";
    }

    QMessageBox::information(this, "Error Check", errorReport);
}

void Receiver::onMessageReceived(const QString& message)
{
    if (!message.isEmpty()) {
        if (message.contains('|') && message.contains('\n')) {
            int headerEnd = message.indexOf('\n');
            QString header = message.left(headerEnd);
            QString messageBody = message.mid(headerEnd + 1);

            parseMessageHeader(header);
            ui->receivedTextEdit->setPlainText(messageBody);
        } else {
            ui->receivedTextEdit->setPlainText(message);
        }

        ui->senderLabel->setText(QString("From SID: %1 → RID: %2").arg(m_sid).arg(m_rid));
        ui->timeLabel->setText("Time: " + m_messageTime);
    }
}

void Receiver::parseMessageHeader(const QString& header)
{
    // Reset defaults
    m_currentSender = "Unknown";
    m_messageTime = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
    m_sid = 0;
    m_rid = 0;
    m_priority = 0;
    m_isEncrypted = false;
    m_compressionType = 0;
    m_payloadSize = 0;

    // Parse header format: SID|RID|PRIORITY|ENCRYPTION|COMPRESSION|SIZE|TIME
    QStringList parts = header.split('|');

    if (parts.size() >= 7) {
        m_sid = parts[0].toInt();
        m_rid = parts[1].toInt();
        m_priority = parts[2].toInt();
        m_isEncrypted = (parts[3].toInt() > 0);
        m_compressionType = parts[4].toInt();
        m_payloadSize = parts[5].toInt();

        QString timeStr = parts[6];
        QDateTime dt = QDateTime::fromString(timeStr, "yyyyMMdd-hhmmss");
        if (dt.isValid()) {
            m_messageTime = dt.toString("yyyy-MM-dd hh:mm:ss");
        }
    }
}

void Receiver::onPlaybackFinished(bool success, const QString& message)
{
    if (success) {
        QMessageBox::information(this, "Playback", message);
    } else {
        QMessageBox::critical(this, "Playback Error", message);
    }
}

void Receiver::onErrorOccurred(const QString& error)
{
    QMessageBox::critical(this, "Error", error);
}
