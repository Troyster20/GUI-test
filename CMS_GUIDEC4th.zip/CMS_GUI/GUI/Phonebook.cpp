#include "Phonebook.h"
#include "ui_Phonebook.h"
#include <QMessageBox>
#include <QInputDialog>
#include <QFile>
#include <QTextStream>

#include "../src/phonebook_backend.h"

Phonebook::Phonebook(CMSController* controller, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Phonebook),
    m_controller(controller)
{
    ui->setupUi(this);

    QStringList logHeaders;
    logHeaders << "SID" << "RID" << "Priority" << "Type" << "Encryption" << "Compression" << "Size" << "Timestamp";
    ui->messageLogTable->setColumnCount(8);
    ui->messageLogTable->setHorizontalHeaderLabels(logHeaders);
    ui->messageLogTable->horizontalHeader()->setStretchLastSection(true);

    QStringList contactHeaders;
    contactHeaders << "Name" << "SID" << "RID" << "COM Port";
    ui->contactsTable->setColumnCount(4);
    ui->contactsTable->setHorizontalHeaderLabels(contactHeaders);
    ui->contactsTable->horizontalHeader()->setStretchLastSection(true);

    refreshMessageLog();
    refreshContactList();
}

Phonebook::~Phonebook()
{
    delete ui;
}

void Phonebook::on_backButton_clicked()
{
    emit backToStart();
}

void Phonebook::on_refreshButton_clicked()
{
    int currentTab = ui->tabWidget->currentIndex();
    if (currentTab == 0) {
        refreshMessageLog();
        QMessageBox::information(this, "Message Log",
                                 QString("Refreshed. Total entries: %1").arg(fnumLogs()));
    } else {
        refreshContactList();
        QMessageBox::information(this, "Contacts",
                                 QString("Refreshed. Total contacts: %1").arg(m_controller->getContactCount()));
    }
}

void Phonebook::on_clearButton_clicked()
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Clear Message Log",
                                  "Delete ALL message log entries?",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        QFile file("phonebook.txt");
        if (file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
            file.close();
            refreshMessageLog();
            QMessageBox::information(this, "Success", "Message log cleared");
        }
    }
}

void Phonebook::on_addContactButton_clicked()
{
    bool ok;
    QString name = QInputDialog::getText(this, "Add Contact",
                                         "Contact name:", QLineEdit::Normal, "", &ok);
    if (!ok || name.isEmpty()) return;

    int sid = QInputDialog::getInt(this, "Add Contact",
                                   "Sender ID (SID):", 1, 1, 9999, 1, &ok);
    if (!ok) return;

    int rid = QInputDialog::getInt(this, "Add Contact",
                                   "Receiver ID (RID):", 2, 1, 9999, 1, &ok);
    if (!ok) return;

    QString port = QInputDialog::getText(this, "Add Contact",
                                         "COM Port:", QLineEdit::Normal, "COM5", &ok);
    if (!ok || port.isEmpty()) return;

    if (m_controller->addContact(name, sid, rid, port)) {
        refreshContactList();
        QMessageBox::information(this, "Success",
                                 QString("Added contact: %1").arg(name));
    } else {
        QMessageBox::warning(this, "Error", "Failed to add contact (phonebook full?)");
    }
}

void Phonebook::on_editContactButton_clicked()
{
    int row = ui->contactsTable->currentRow();
    if (row < 0) {
        QMessageBox::warning(this, "No Selection", "Select a contact to edit");
        return;
    }

    QString oldName = ui->contactsTable->item(row, 0)->text();
    int oldSID = ui->contactsTable->item(row, 1)->text().toInt();
    int oldRID = ui->contactsTable->item(row, 2)->text().toInt();
    QString oldPort = ui->contactsTable->item(row, 3)->text();

    bool ok;
    QString name = QInputDialog::getText(this, "Edit Contact",
                                         "Name:", QLineEdit::Normal, oldName, &ok);
    if (!ok) return;

    int sid = QInputDialog::getInt(this, "Edit Contact",
                                   "SID:", oldSID, 1, 9999, 1, &ok);
    if (!ok) return;

    int rid = QInputDialog::getInt(this, "Edit Contact",
                                   "RID:", oldRID, 1, 9999, 1, &ok);
    if (!ok) return;

    QString port = QInputDialog::getText(this, "Edit Contact",
                                         "COM Port:", QLineEdit::Normal, oldPort, &ok);
    if (!ok) return;

    if (m_controller->editContact(row, name, sid, rid, port)) {
        refreshContactList();
        QMessageBox::information(this, "Success", "Contact updated");
    } else {
        QMessageBox::warning(this, "Error", "Failed to update contact");
    }
}

void Phonebook::on_deleteContactButton_clicked()
{
    int row = ui->contactsTable->currentRow();
    if (row < 0) {
        QMessageBox::warning(this, "No Selection", "Select a contact to delete");
        return;
    }

    QString name = ui->contactsTable->item(row, 0)->text();

    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Delete Contact",
                                  QString("Delete '%1'?").arg(name),
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        if (m_controller->removeContact(row)) {
            refreshContactList();
            QMessageBox::information(this, "Success",
                                     QString("Deleted: %1").arg(name));
        }
    }
}

void Phonebook::on_tabWidget_currentChanged(int index)
{
    if (index == 0) {
        refreshMessageLog();
    } else if (index == 1) {
        refreshContactList();
    }
}

void Phonebook::refreshMessageLog()
{
    ui->messageLogTable->setRowCount(0);

    QFile file("phonebook.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        ui->messageLogTable->setRowCount(1);
        ui->messageLogTable->setItem(0, 0, new QTableWidgetItem("No message logs"));
        return;
    }

    QTextStream in(&file);
    QString currentEntry;
    int row = 0;

    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();

        if (line == "%") {
            if (!currentEntry.isEmpty()) {
                parseAndAddEntry(currentEntry, row);
                row++;
                currentEntry.clear();
            }
        } else {
            if (!currentEntry.isEmpty()) currentEntry += "\n";
            currentEntry += line;
        }
    }

    if (!currentEntry.isEmpty()) {
        parseAndAddEntry(currentEntry, row);
    }

    file.close();

    if (ui->messageLogTable->rowCount() == 0) {
        ui->messageLogTable->setRowCount(1);
        ui->messageLogTable->setItem(0, 0, new QTableWidgetItem("No entries"));
    }
}

void Phonebook::parseAndAddEntry(const QString& entry, int row)
{
    ui->messageLogTable->insertRow(row);

    QStringList lines = entry.split('\n');
    QString sid, rid, priority, type, encryption, compression, size, timestamp;

    for (const QString& line : lines) {
        if (line.startsWith("SID:")) sid = line.mid(4).trimmed();
        else if (line.startsWith("RID:")) rid = line.mid(4).trimmed();
        else if (line.startsWith("Priority:")) priority = line.mid(9).trimmed();
        else if (line.startsWith("Payload Type:")) type = line.mid(13).trimmed();
        else if (line.startsWith("Encryption:")) encryption = line.mid(11).trimmed();
        else if (line.startsWith("Compression:")) compression = line.mid(12).trimmed();
        else if (line.startsWith("Payload Size:")) size = line.mid(13).trimmed();
        else if (line.startsWith("Timestamp:")) timestamp = line.mid(10).trimmed();
    }

    ui->messageLogTable->setItem(row, 0, new QTableWidgetItem(sid));
    ui->messageLogTable->setItem(row, 1, new QTableWidgetItem(rid));
    ui->messageLogTable->setItem(row, 2, new QTableWidgetItem(priority));
    ui->messageLogTable->setItem(row, 3, new QTableWidgetItem(type));
    ui->messageLogTable->setItem(row, 4, new QTableWidgetItem(encryption));
    ui->messageLogTable->setItem(row, 5, new QTableWidgetItem(compression));
    ui->messageLogTable->setItem(row, 6, new QTableWidgetItem(size));
    ui->messageLogTable->setItem(row, 7, new QTableWidgetItem(timestamp));
}

void Phonebook::refreshContactList()
{
    m_controller->refreshContacts(ui->contactsTable);
}
