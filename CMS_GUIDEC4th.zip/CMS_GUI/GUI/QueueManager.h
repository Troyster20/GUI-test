#ifndef QUEUEMANAGER_H
#define QUEUEMANAGER_H

#include <QWidget>
#include "CMSController.h"

namespace Ui {
class QueueManager;
}

class QueueManager : public QWidget
{
    Q_OBJECT

public:
    explicit QueueManager(CMSController* controller, QWidget *parent = nullptr);
    ~QueueManager();

    void refreshQueueDisplay();  // Update the queue list

signals:
    void backToTransmitter();

private slots:
    void on_backButton_clicked();
    void on_playButton_clicked();
    void on_sendButton_clicked();
    void on_deleteButton_clicked();
    void on_refreshButton_clicked();

    void onPlaybackFinished(bool success, const QString& message);
    void onMessageSent(bool success, const QString& message);

private:
    int getSelectedIndex();  // Get the index of selected item

    Ui::QueueManager *ui;
    CMSController* m_controller;
};

#endif // QUEUEMANAGER_H
