#ifndef PHONEBOOK_H
#define PHONEBOOK_H

#include <QWidget>
#include <QTableWidgetItem>
#include "CMSController.h"

namespace Ui {
class Phonebook;
}

class Phonebook : public QWidget
{
    Q_OBJECT

public:
    explicit Phonebook(CMSController* controller, QWidget *parent = nullptr);
    ~Phonebook();

signals:
    void backToStart();

private slots:
    void on_backButton_clicked();
    void on_refreshButton_clicked();
    void on_clearButton_clicked();
    void on_addContactButton_clicked();
    void on_editContactButton_clicked();
    void on_deleteContactButton_clicked();
    void on_tabWidget_currentChanged(int index);

private:
    void refreshMessageLog();
    void refreshContactList();
    void parseAndAddEntry(const QString& entry, int row);

    Ui::Phonebook *ui;
    CMSController* m_controller;
};

#endif
