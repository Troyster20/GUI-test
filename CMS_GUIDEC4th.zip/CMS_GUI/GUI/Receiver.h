#ifndef RECEIVER_H
#define RECEIVER_H

#include <QWidget>
#include "CMSController.h"

namespace Ui {
class Receiver;
}

class Receiver : public QWidget
{
    Q_OBJECT

public:
    explicit Receiver(CMSController* controller, QWidget *parent = nullptr);
    ~Receiver();

signals:
    void backToStart();

private slots:
    void on_backButton_clicked();
    void on_playTextButton_clicked();
    void on_playAudioButton_clicked();
    void on_viewHeaderButton_clicked();
    void on_checkErrorsButton_clicked();

    void onMessageReceived(const QString& message);
    void onPlaybackFinished(bool success, const QString& message);
    void onErrorOccurred(const QString& error);

private:
    void parseMessageHeader(const QString& header);

    Ui::Receiver *ui;
    CMSController* m_controller;

    // Header data
    QString m_currentSender;
    QString m_messageTime;
    int m_sid;
    int m_rid;
    int m_priority;
    bool m_isEncrypted;
    int m_compressionType;
    int m_payloadSize;
};

#endif
