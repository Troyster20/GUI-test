#include "MainWindow.h"
#include "StartMenu.h"
#include "Transmitter.h"
#include "Receiver.h"
#include "Testing.h"
#include "Phonebook.h"
#include "Settings.h"
#include "CMSController.h"

#include <QVBoxLayout>
#include <QMessageBox>
#include <QApplication>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , stackedWidget(nullptr)
    , startMenu(nullptr)
    , transmitter(nullptr)
    , receiver(nullptr)
    , testing(nullptr)
    , phonebook(nullptr)
    , settings(nullptr)
    , controller(new CMSController(this))
{
    setupUI();
    connectSignals();
    showStartMenu();

    setWindowTitle("CMS Project - Kien Matthew Troy");
    setMinimumSize(800, 600);
    resize(1000, 700);
}
MainWindow::~MainWindow()
{
}

void MainWindow::setupUI()
{
    QWidget *centralWidget = new QWidget(this);
    stackedWidget = new QStackedWidget(centralWidget);

    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->addWidget(stackedWidget);

    setCentralWidget(centralWidget);

    startMenu = new StartMenu(controller, this);
    transmitter = new Transmitter(controller, this);
    receiver = new Receiver(controller, this);
    testing = new Testing(controller, this);
    phonebook = new Phonebook(controller, this);
    settings = new Settings(controller, this);

    stackedWidget->addWidget(startMenu);
    stackedWidget->addWidget(transmitter);
    stackedWidget->addWidget(receiver);
    stackedWidget->addWidget(testing);
    stackedWidget->addWidget(phonebook);
    stackedWidget->addWidget(settings);
}

void MainWindow::connectSignals()
{
    connect(startMenu, &StartMenu::showTransmitter, this, &MainWindow::showTransmitter);
    connect(startMenu, &StartMenu::showReceiver, this, &MainWindow::showReceiver);
    connect(startMenu, &StartMenu::showTesting, this, &MainWindow::showTesting);
    connect(startMenu, &StartMenu::showPhonebook, this, &MainWindow::showPhonebook);
    connect(startMenu, &StartMenu::showSettings, this, &MainWindow::showSettings);
    connect(startMenu, &StartMenu::quitApplication, this, &MainWindow::quitApplication);

    connect(transmitter, &Transmitter::backToStart, this, &MainWindow::showStartMenu);
    connect(receiver, &Receiver::backToStart, this, &MainWindow::showStartMenu);
    connect(testing, &Testing::backToStart, this, &MainWindow::showStartMenu);
    connect(phonebook, &Phonebook::backToStart, this, &MainWindow::showStartMenu);
    connect(settings, &Settings::backToStart, this, &MainWindow::showStartMenu);
}

void MainWindow::showStartMenu()
{
    stackedWidget->setCurrentWidget(startMenu);
}

void MainWindow::showTransmitter()
{
    stackedWidget->setCurrentWidget(transmitter);
}

void MainWindow::showReceiver()
{
    stackedWidget->setCurrentWidget(receiver);
}
void MainWindow::showTesting()
{
    stackedWidget->setCurrentWidget(testing);
}

void MainWindow::showPhonebook()
{
    stackedWidget->setCurrentWidget(phonebook);
}

void MainWindow::showSettings()
{
    stackedWidget->setCurrentWidget(settings);
}

void MainWindow::quitApplication()
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Quit", "Are you sure you want to quit?",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        QApplication::quit();
    }
}
