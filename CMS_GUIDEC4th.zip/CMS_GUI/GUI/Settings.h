#ifndef SETTINGS_H
#define SETTINGS_H

#include <QWidget>
#include "CMSController.h"

namespace Ui {
class Settings;
}

class Settings : public QWidget
{
    Q_OBJECT

public:
    explicit Settings(CMSController* controller, QWidget *parent = nullptr);
    ~Settings();

signals:
    void backToStart();

private slots:
    void on_backButton_clicked();
    void on_saveButton_clicked();
    void on_defaultsButton_clicked();

private:
    void updateSettingsDisplay();

    Ui::Settings *ui;
    CMSController* m_controller;
};

#endif // SETTINGS_H
