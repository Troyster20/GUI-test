#include "Transmitter.h"
#include "ui_Transmitter.h"
#include <QMessageBox>
#include <QFileDialog>
#include <QInputDialog>
#include <QDateTime>
#include <QProgressDialog>
#include <QApplication>
#include <QTimer>

Transmitter::Transmitter(CMSController* controller, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Transmitter),
    m_controller(controller)
{
    ui->setupUi(this);

    connect(m_controller, &CMSController::recordingFinished, this, &Transmitter::onRecordingFinished);
    connect(m_controller, &CMSController::playbackFinished, this, &Transmitter::onPlaybackFinished);
    connect(m_controller, &CMSController::errorOccurred, this, &Transmitter::onErrorOccurred);

    ui->dateTimeLabel->setText(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"));

    ui->sidSpinBox->setValue(m_controller->getDefaultSID());
    ui->ridSpinBox->setValue(m_controller->getDefaultRID());
    ui->prioritySpinBox->setValue(m_controller->getDefaultPriority());

    if (!m_controller->initializeTransmitter()) {
        QMessageBox::warning(this, "COM Port Warning",
                             "Transmitter COM port init failed");
    }

    loadContacts();
    updateQueueInfo();
}

Transmitter::~Transmitter()
{
    delete ui;
}

void Transmitter::on_backButton_clicked()
{
    emit backToStart();
}

void Transmitter::on_newTextButton_clicked()
{
    ui->messageTextEdit->clear();
    ui->messageTextEdit->setFocus();
    QMessageBox::information(this, "New Text", "Ready to create new text message");
}

void Transmitter::on_newAudioButton_clicked()
{
    bool ok;
    QString name = QInputDialog::getText(this, "Record Audio",
                                         "Enter name for recording:",
                                         QLineEdit::Normal, "", &ok);
    if (!ok || name.isEmpty()) return;

    QProgressDialog* progress = new QProgressDialog(
        "Recording in progress...\n\n"
        "Speak into microphone now!\n"
        "Recording will last 6 seconds.",
        "Cancel", 0, 100, this);

    progress->setWindowTitle("Recording Audio");
    progress->setWindowModality(Qt::WindowModal);
    progress->setMinimumDuration(0);
    progress->setCancelButton(nullptr);
    progress->setValue(0);
    progress->show();
    QApplication::processEvents();

    const int recordTime = 6000;
    const int updateInterval = 100;
    int elapsed = 0;

    progress->setValue(5);
    QApplication::processEvents();

    QTimer* timer = new QTimer(this);
    connect(timer, &QTimer::timeout, [&]() {
        elapsed += updateInterval;
        int progressValue = (elapsed * 100) / recordTime;
        if (progressValue > 100) progressValue = 100;
        progress->setValue(progressValue);
        QApplication::processEvents();
    });

    timer->start(updateInterval);

    bool success = m_controller->startRecording(name);

    timer->stop();
    delete timer;
    progress->setValue(100);
    progress->close();
    delete progress;

    if (success) {
        updateQueueInfo();
    }
}

void Transmitter::on_sendButton_clicked()
{
    QString message = ui->messageTextEdit->toPlainText();
    if (message.isEmpty()) {
        QMessageBox::warning(this, "Empty Message", "Enter a message before sending");
        return;
    }

    int sid = ui->sidSpinBox->value();
    int rid = ui->ridSpinBox->value();
    int priority = ui->prioritySpinBox->value();
    int encryption = ui->encryptCheckBox->isChecked() ? 1 : 0;
    int compression = 0;
    if (ui->huffmanRadio->isChecked()) compression = 1;
    else if (ui->rleRadio->isChecked()) compression = 2;

    if (m_controller->sendTextMessageWithPriority(message, priority, sid, rid, encryption, compression)) {
        QString status = QString("Message sent\nSID: %1  RID: %2  Priority: %3\nEncryption: %4  Compression: %5")
        .arg(sid).arg(rid).arg(priority)
            .arg(encryption ? "XOR" : "OFF")
            .arg(compression == 1 ? "Huffman" : compression == 2 ? "RLE" : "OFF");

        QMessageBox::information(this, "Message Sent", status);

        if (ui->saveToFileCheckBox->isChecked()) {
            on_saveButton_clicked();
        }
    } else {
        QMessageBox::critical(this, "Send Error", "Failed to send message");
    }
}

void Transmitter::on_saveButton_clicked()
{
    QString message = ui->messageTextEdit->toPlainText();
    if (message.isEmpty()) {
        QMessageBox::warning(this, "Empty Message", "No message to save");
        return;
    }

    QString fileName = QFileDialog::getSaveFileName(this, "Save Message", "", "Text Files (*.txt)");
    if (!fileName.isEmpty()) {
        QFile file(fileName);
        if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            QTextStream out(&file);
            out << "CMS Message\n";
            out << "Time: " << QDateTime::currentDateTime().toString() << "\n";
            out << "SID: " << ui->sidSpinBox->value() << "\n";
            out << "RID: " << ui->ridSpinBox->value() << "\n";
            out << "Message:\n" << message << "\n";
            file.close();
            QMessageBox::information(this, "Success", "Message saved to file");
        } else {
            QMessageBox::critical(this, "Error", "Could not save file");
        }
    }
}

void Transmitter::on_playQueueButton_clicked()
{
    m_controller->playCurrentAudio();
}

void Transmitter::on_deleteQueueButton_clicked()
{
    if (m_controller->deleteCurrentAudio()) {
        QMessageBox::information(this, "Success", "Audio message deleted from queue");
        updateQueueInfo();
    } else {
        QMessageBox::warning(this, "Error", "No audio message to delete");
    }
}

void Transmitter::on_recipientComboBox_currentIndexChanged(int index)
{
    if (index <= 0) return; // "Manual Entry" selected

    int contactIndex = index - 1; // Adjust for "Manual Entry" at position 0

    // Load contact info into spinboxes
    int sid = m_controller->getContactSID(contactIndex);
    int rid = m_controller->getContactRID(contactIndex);

    if (sid > 0 && rid > 0) {
        ui->sidSpinBox->setValue(sid);
        ui->ridSpinBox->setValue(rid);

        QString contactName = m_controller->getContactName(contactIndex);
        QMessageBox::information(this, "Contact Selected",
                                 QString("Loaded contact: %1\nSID: %2  RID: %3").arg(contactName).arg(sid).arg(rid));
    }
}

void Transmitter::on_refreshContactsButton_clicked()
{
    loadContacts();
    QMessageBox::information(this, "Contacts",
                             QString("Loaded %1 contacts from phonebook").arg(m_controller->getContactCount()));
}

void Transmitter::onRecordingFinished(bool success, const QString& message)
{
    if (success) {
        QMessageBox::information(this, "Recording Complete", message);
        updateQueueInfo();
    } else {
        QMessageBox::critical(this, "Recording Failed", message);
    }
}

void Transmitter::onPlaybackFinished(bool success, const QString& message)
{
    if (success) {
        QMessageBox::information(this, "Playback", message);
    } else {
        QMessageBox::critical(this, "Playback Error", message);
    }
}

void Transmitter::onErrorOccurred(const QString& error)
{
    QMessageBox::critical(this, "Error", error);
}

void Transmitter::updateQueueInfo()
{
    int messageCount = m_controller->getMessageCount();
    QString currentMessage = m_controller->getCurrentMessageName();

    QString queueInfo = QString("Queue: %1 messages - Current: %2")
                            .arg(messageCount)
                            .arg(currentMessage.isEmpty() ? "None" : currentMessage);

    ui->queueInfoLabel->setText(queueInfo);
}

void Transmitter::loadContacts()
{
    ui->recipientComboBox->clear();
    ui->recipientComboBox->addItem("Manual Entry");

    int contactCount = m_controller->getContactCount();

    for (int i = 0; i < contactCount; i++) {
        QString name = m_controller->getContactName(i);
        int sid = m_controller->getContactSID(i);
        int rid = m_controller->getContactRID(i);

        QString displayText = QString("%1 (SID:%2 RID:%3)").arg(name).arg(sid).arg(rid);
        ui->recipientComboBox->addItem(displayText);
    }
}
