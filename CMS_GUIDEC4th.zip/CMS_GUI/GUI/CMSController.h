#ifndef CMSCONTROLLER_H
#define CMSCONTROLLER_H

#include <QObject>
#include <QString>
#include <QTableWidget>

#ifdef _WIN32
#include <windows.h>
#endif

class CMSController : public QObject
{
    Q_OBJECT

public:
    explicit CMSController(QObject *parent = nullptr);
    ~CMSController();

    Q_INVOKABLE bool startRecording(const QString& filename);
    Q_INVOKABLE bool playCurrentAudio();
    Q_INVOKABLE bool saveCurrentAudio(const QString& filename);
    Q_INVOKABLE bool deleteCurrentAudio();

    Q_INVOKABLE bool initializeTransmitter(const QString& portName = "COM6");
    Q_INVOKABLE bool initializeReceiver(const QString& portName = "COM7");

    Q_INVOKABLE bool sendTextMessageWithPriority(const QString& message, int priority,
                                                 int sid, int rid, int encryption, int compression);
    Q_INVOKABLE bool sendAudioMessageWithPriority(int queueIndex, int priority,
                                                  int sid, int rid, int encryption, int compression);
    Q_INVOKABLE QString receiveTextMessage();
    Q_INVOKABLE bool receiveAudioMessage();

    Q_INVOKABLE int getMessageCount() const;
    Q_INVOKABLE QString getCurrentMessageName() const;

    Q_INVOKABLE void loadConfigFromFile();
    Q_INVOKABLE void saveConfigToFile();
    Q_INVOKABLE int getContactCount() const;
    Q_INVOKABLE bool addContact(const QString& name, int sid, int rid, const QString& port);
    Q_INVOKABLE bool editContact(int index, const QString& name, int sid, int rid, const QString& port);
    Q_INVOKABLE bool removeContact(int index);
    Q_INVOKABLE void refreshContacts(QTableWidget* table);

    Q_INVOKABLE QString getContactName(int index) const;
    Q_INVOKABLE int getContactSID(int index) const;
    Q_INVOKABLE int getContactRID(int index) const;
    Q_INVOKABLE QString getContactPort(int index) const;

    Q_INVOKABLE QString getTxPort() const;
    Q_INVOKABLE QString getRxPort() const;
    Q_INVOKABLE int getBaudRate() const;
    Q_INVOKABLE int getDefaultSID() const;
    Q_INVOKABLE int getDefaultRID() const;
    Q_INVOKABLE int getDefaultPriority() const;

    Q_INVOKABLE void setTxPort(const QString& port);
    Q_INVOKABLE void setRxPort(const QString& port);
    Q_INVOKABLE void setBaudRate(int baud);
    Q_INVOKABLE void setDefaultSID(int sid);
    Q_INVOKABLE void setDefaultRID(int rid);
    Q_INVOKABLE void setDefaultPriority(int priority);

    Q_INVOKABLE void initializeSystems();
    Q_INVOKABLE void cleanupSystems();

signals:
    void recordingFinished(bool success, const QString& message);
    void playbackFinished(bool success, const QString& message);
    void messageSent(bool success, const QString& message);
    void messageReceived(const QString& message);
    void errorOccurred(const QString& error);

private:
    bool systemsInitialized;
    HANDLE m_hComTx;
    HANDLE m_hComRx;
};

#endif
