#ifndef TESTING_H
#define TESTING_H

#include <QWidget>
#include "CMSController.h"

namespace Ui {
class Testing;
}

class Testing : public QWidget
{
    Q_OBJECT

public:
    explicit Testing(CMSController* controller, QWidget *parent = nullptr);
    ~Testing();

signals:
    void backToStart();

private slots:
    void on_backButton_clicked();
    void on_hardwareTestButton_clicked();
    void on_loopbackTestButton_clicked();
    void on_headerTestButton_clicked();
    void on_errorTestButton_clicked();
    void on_encryptionTestButton_clicked();

private:
    Ui::Testing *ui;
    CMSController* m_controller;
};

#endif //TESTING_H
