#include "CMSController.h"
#include <QDebug>
#include <QMessageBox>
#include <QInputDialog>
#include <QDateTime>
#include <QThread>
#include <QTableWidgetItem>

#include "../src/sound.h"
#include "../src/audioQueue.h"
#include "../src/RS232Comm.h"
#include "../src/ui.h"
#include "../src/config.h"
#include "../src/phonebook_backend.h"
#include "../src/Header.h"
#include "../src/compress.h"

extern "C" {
void enqueue(short* buf, long size, const char* name);
link deQueue();
link peekQueue();

void xor_encrypt(unsigned char* data, int size);
void xor_decrypt(unsigned char* data, int size);
unsigned char* huffman_encode(const unsigned char* data, int size, int* out_size);
unsigned char* huffman_decode(const unsigned char* data, int size, int* out_size);
unsigned char* rle_encode(const unsigned char* data, int size, int* out_size);
unsigned char* rle_decode(const unsigned char* data, int size, int* out_size);
}

extern short iBigBuf[];
extern long lBigBufSize;
extern int nComRate;
extern int nComBits;
extern COMMTIMEOUTS timeout;
extern int messageCount;

static Config g_config;

CMSController::CMSController(QObject *parent)
    : QObject(parent)
    , systemsInitialized(false)
    , m_hComTx(INVALID_HANDLE_VALUE)
    , m_hComRx(INVALID_HANDLE_VALUE)
{
    loadConfigFromFile();
    initializeSystems();
}

CMSController::~CMSController()
{
    cleanupSystems();
}

void CMSController::initializeSystems()
{
    if (!systemsInitialized) {
        initQueue();
        systemsInitialized = true;
        qDebug() << "CMS Systems initialized";
    }
}

void CMSController::cleanupSystems()
{
    if (systemsInitialized) {
        ClosePlayback();
        CloseRecording();
        clearQueue();

        if (m_hComTx != INVALID_HANDLE_VALUE) {
            CloseHandle(m_hComTx);
            m_hComTx = INVALID_HANDLE_VALUE;
        }
        if (m_hComRx != INVALID_HANDLE_VALUE) {
            CloseHandle(m_hComRx);
            m_hComRx = INVALID_HANDLE_VALUE;
        }

        systemsInitialized = false;
        qDebug() << "CMS Systems cleaned up";
    }
}

bool CMSController::startRecording(const QString& filename)
{
    if (!systemsInitialized) {
        emit errorOccurred("Systems not initialized");
        return false;
    }

    QByteArray ba = filename.toLocal8Bit();
    const char* name = ba.constData();

    qDebug() << "Starting recording:" << filename;

    CloseRecording();
    QThread::msleep(100);

    if (!InitializeRecording()) {
        QString errorMsg = "MICROPHONE INITIALIZATION FAILED\n\n"
                           "Troubleshooting steps:\n"
                           "1. Check microphone is plugged in\n"
                           "2. Windows Settings → Privacy → Microphone → Allow apps\n"
                           "3. Right-click speaker icon → Sounds → Recording tab\n"
                           "   - Ensure microphone is set as DEFAULT device\n"
                           "   - Ensure microphone is NOT disabled\n"
                           "4. Close any other apps using microphone\n"
                           "5. Try running as Administrator";

        qDebug() << "Recording device initialization failed";
        emit recordingFinished(false, errorMsg);
        emit errorOccurred(errorMsg);
        return false;
    }

    qDebug() << "Recording device initialized successfully";

    bool success = RecordBuffer(iBigBuf, lBigBufSize);

    if (success) {
        qDebug() << "Recording completed successfully";
        enqueue(iBigBuf, lBigBufSize, name);
        QString successMsg = QString("Recording '%1' completed successfully!\n"
                                     "Duration: %2 seconds\n"
                                     "Message added to queue.").arg(filename).arg(RECORD_TIME);
        emit recordingFinished(true, successMsg);
    } else {
        QString errorMsg = "RECORDING FAILED\n\n"
                           "The recording operation did not complete successfully.\n\n"
                           "Possible causes:\n"
                           "- Microphone disconnected during recording\n"
                           "- Audio driver crashed\n"
                           "- Insufficient system resources";

        qDebug() << "RecordBuffer returned false";
        emit recordingFinished(false, errorMsg);
        emit errorOccurred(errorMsg);
    }

    return success;
}

bool CMSController::playCurrentAudio()
{
    if (!systemsInitialized) {
        emit errorOccurred("Systems not initialized");
        return false;
    }

    if (isQueueEmpty()) {
        emit errorOccurred("Queue is empty. No messages to play");
        return false;
    }

    link frontNode = peekQueue();
    if (!frontNode) {
        emit errorOccurred("No audio message to play");
        return false;
    }

    QString messageName = QString::fromLocal8Bit(frontNode->Data.filename);
    qDebug() << "Playing audio:" << messageName;

    ClosePlayback();
    QThread::msleep(50);

    if (!InitializePlayback()) {
        emit errorOccurred("Audio output device not available");
        return false;
    }

    bool success = PlayBuffer(frontNode->Data.buffer, frontNode->Data.size);

    if (success) {
        emit playbackFinished(true, QString("Playback of '%1' completed").arg(messageName));
    } else {
        emit playbackFinished(false, "Playback failed - check speakers/audio output");
        emit errorOccurred("Playback failed - check speakers/audio output");
    }

    return success;
}

bool CMSController::saveCurrentAudio(const QString& filename)
{
    if (!systemsInitialized) {
        emit errorOccurred("Systems not initialized");
        return false;
    }

    if (isQueueEmpty()) {
        emit errorOccurred("Queue is empty. Nothing to save");
        return false;
    }

    link frontNode = peekQueue();
    if (!frontNode) {
        return false;
    }

    QByteArray ba = filename.toLocal8Bit();
    const char* name = ba.constData();

    saveAudio(frontNode->Data.buffer, frontNode->Data.size, name);

    qDebug() << "Audio saved:" << filename;
    return true;
}

bool CMSController::deleteCurrentAudio()
{
    if (!systemsInitialized) {
        emit errorOccurred("Systems not initialized");
        return false;
    }

    if (isQueueEmpty()) {
        emit errorOccurred("Queue is empty. Nothing to delete");
        return false;
    }

    link deleted = deQueue();
    if (deleted) {
        QString deletedName = QString::fromLocal8Bit(deleted->Data.filename);
        free(deleted->Data.buffer);
        free(deleted);
        qDebug() << "Deleted audio:" << deletedName;
        return true;
    }

    return false;
}

bool CMSController::initializeTransmitter(const QString& portName)
{
    if (!systemsInitialized) {
        emit errorOccurred("Systems not initialized");
        return false;
    }

    if (m_hComTx != INVALID_HANDLE_VALUE) {
        CloseHandle(m_hComTx);
        m_hComTx = INVALID_HANDLE_VALUE;
    }

    std::wstring port = portName.toStdWString();
    const wchar_t* portW = port.c_str();

    m_hComTx = setupComPort(portW, g_config.baudRate, nComBits, timeout);
    bool success = (m_hComTx != INVALID_HANDLE_VALUE);

    if (success) {
        qDebug() << "Transmitter initialized on" << portName;
    } else {
        qDebug() << "Failed to initialize transmitter on" << portName;
    }

    return success;
}

bool CMSController::initializeReceiver(const QString& portName)
{
    if (!systemsInitialized) {
        emit errorOccurred("Systems not initialized");
        return false;
    }

    if (m_hComRx != INVALID_HANDLE_VALUE) {
        CloseHandle(m_hComRx);
        m_hComRx = INVALID_HANDLE_VALUE;
    }

    std::wstring port = portName.toStdWString();
    const wchar_t* portW = port.c_str();

    m_hComRx = setupComPort(portW, g_config.baudRate, nComBits, timeout);
    bool success = (m_hComRx != INVALID_HANDLE_VALUE);

    if (success) {
        qDebug() << "Receiver initialized on" << portName;
    } else {
        qDebug() << "Failed to initialize receiver on" << portName;
    }

    return success;
}

bool CMSController::sendTextMessageWithPriority(const QString& message, int priority,
                                                int sid, int rid, int encryption, int compression)
{
    if (!systemsInitialized) {
        emit errorOccurred("Systems not initialized");
        return false;
    }

    if (message.isEmpty()) {
        emit errorOccurred("Cannot send empty message");
        return false;
    }

    if (m_hComTx == INVALID_HANDLE_VALUE) {
        if (!initializeTransmitter()) {
            if (!initializeTransmitter("COM7")) {
                emit errorOccurred("Transmitter not available");
                return false;
            }
        }
    }

    if (sid == 0) sid = g_config.defaultSID;
    if (rid == 0) rid = g_config.defaultRID;
    if (priority == 0) priority = g_config.defaultPriority;

    qDebug() << "=== sendTextMessageWithPriority ===";
    qDebug() << "Message:" << message;
    qDebug() << "SID:" << sid << "RID:" << rid << "Priority:" << priority;
    qDebug() << "Encryption:" << encryption << "Compression:" << compression;

    QByteArray messageBytes = message.toLocal8Bit();
    const unsigned char* originalData = reinterpret_cast<const unsigned char*>(messageBytes.constData());
    int originalSize = messageBytes.size();

    unsigned char* processedData = nullptr;
    int processedSize = originalSize;
    bool needsFree = false;

    if (encryption == 1) {
        qDebug() << "Applying XOR encryption...";
        processedData = (unsigned char*)malloc(originalSize);
        memcpy(processedData, originalData, originalSize);
        xor_encrypt(processedData, originalSize);
        needsFree = true;
        qDebug() << "XOR encryption applied";
    } else {
        processedData = (unsigned char*)originalData;
    }

    unsigned char* compressedData = nullptr;
    int compressedSize = processedSize;

    if (compression == 1) {
        qDebug() << "Attempting Huffman compression...";
        compressedData = huffman_encode(processedData, processedSize, &compressedSize);
        if (compressedData && compressedSize < processedSize) {
            qDebug() << "Huffman: compressed from" << processedSize << "to" << compressedSize << "bytes";
            if (needsFree) free(processedData);
            processedData = compressedData;
            processedSize = compressedSize;
            needsFree = true;
        } else {
            qDebug() << "Huffman: no benefit, sending uncompressed";
            if (compressedData) free(compressedData);
            compression = 0;
        }
    } else if (compression == 2) {
        qDebug() << "Attempting RLE compression...";
        compressedData = rle_encode(processedData, processedSize, &compressedSize);
        if (compressedData && compressedSize < processedSize) {
            qDebug() << "RLE: compressed from" << processedSize << "to" << compressedSize << "bytes";
            if (needsFree) free(processedData);
            processedData = compressedData;
            processedSize = compressedSize;
            needsFree = true;
        } else {
            qDebug() << "RLE: no benefit, sending uncompressed";
            if (compressedData) free(compressedData);
            compression = 0;
        }
    }

    Header h;
    h.sid = sid;
    h.rid = rid;
    h.priority = priority;
    h.payLoadType = 2;
    h.encryption = encryption;
    h.compression = compression;
    h.payloadSize = processedSize;

    logHeaderToPhonebook(&h);

    QString timestamp = QDateTime::currentDateTime().toString("yyyyMMdd-hhmmss");
    QString headerStr = QString("%1|%2|%3|%4|%5|%6|%7\n")
                            .arg(sid)
                            .arg(rid)
                            .arg(priority)
                            .arg(encryption)
                            .arg(compression)
                            .arg(processedSize)
                            .arg(timestamp);

    QByteArray headerBytes = headerStr.toLocal8Bit();

    int totalSize = headerBytes.size() + processedSize;
    unsigned char* fullMessage = (unsigned char*)malloc(totalSize);

    memcpy(fullMessage, headerBytes.constData(), headerBytes.size());
    memcpy(fullMessage + headerBytes.size(), processedData, processedSize);

    outputToPort(&m_hComTx, fullMessage, totalSize);

    qDebug() << "Sent TEXT message: SID=" << sid << "RID=" << rid << "Priority=" << priority;
    qDebug() << "Header:" << headerStr.trimmed();

    free(fullMessage);
    if (needsFree && processedData) {
        free(processedData);
    }

    emit messageSent(true, QString("Text message sent (SID:%1 RID:%2)").arg(sid).arg(rid));
    return true;
}

bool CMSController::sendAudioMessageWithPriority(int queueIndex, int priority,
                                                 int sid, int rid, int encryption, int compression)
{
    if (!systemsInitialized) {
        emit errorOccurred("Systems not initialized");
        return false;
    }

    if (isQueueEmpty()) {
        emit errorOccurred("Queue is empty");
        return false;
    }

    if (m_hComTx == INVALID_HANDLE_VALUE) {
        if (!initializeTransmitter()) {
            emit errorOccurred("Transmitter not available");
            return false;
        }
    }

    if (sid == 0) sid = g_config.defaultSID;
    if (rid == 0) rid = g_config.defaultRID;
    if (priority == 0) priority = g_config.defaultPriority;

    link audioNode = peekQueue();
    if (!audioNode) {
        emit errorOccurred("No audio in queue");
        return false;
    }

    qDebug() << "=== sendAudioMessage (unified protocol) ===";
    qDebug() << "Sending AUDIO message:" << audioNode->Data.filename;
    qDebug() << "Size:" << audioNode->Data.size * sizeof(short) << "bytes ("
             << (audioNode->Data.size * sizeof(short)) / 1024 << "KB)";
    qDebug() << "At" << g_config.baudRate << "baud, estimated time: ~"
             << ((audioNode->Data.size * sizeof(short) * 10) / g_config.baudRate) << "seconds";

    unsigned char* audioBytes = (unsigned char*)audioNode->Data.buffer;
    int audioSize = audioNode->Data.size * sizeof(short);

    unsigned char* processedData = nullptr;
    int processedSize = audioSize;
    bool needsFree = false;

    if (encryption == 1) {
        qDebug() << "Applying XOR encryption...";
        processedData = (unsigned char*)malloc(audioSize);
        memcpy(processedData, audioBytes, audioSize);
        xor_encrypt(processedData, audioSize);
        needsFree = true;
        qDebug() << "XOR encryption applied";
    } else {
        processedData = audioBytes;
    }

    unsigned char* compressedData = nullptr;
    int compressedSize = processedSize;

    if (compression == 1) {
        qDebug() << "Attempting Huffman compression...";
        compressedData = huffman_encode(processedData, processedSize, &compressedSize);
        if (compressedData && compressedSize < processedSize) {
            qDebug() << "Huffman: compressed from" << processedSize << "to" << compressedSize;
            if (needsFree) free(processedData);
            processedData = compressedData;
            processedSize = compressedSize;
            needsFree = true;
        } else {
            qDebug() << "Huffman: no benefit";
            if (compressedData) free(compressedData);
            compression = 0;
        }
    } else if (compression == 2) {
        qDebug() << "Attempting RLE compression...";
        compressedData = rle_encode(processedData, processedSize, &compressedSize);
        if (compressedData && compressedSize < processedSize) {
            qDebug() << "RLE: compressed from" << processedSize << "to" << compressedSize;
            if (needsFree) free(processedData);
            processedData = compressedData;
            processedSize = compressedSize;
            needsFree = true;
        } else {
            qDebug() << "RLE: no benefit";
            if (compressedData) free(compressedData);
            compression = 0;
        }
    }

    Header h;
    h.sid = sid;
    h.rid = rid;
    h.priority = priority;
    h.payLoadType = 1;
    h.encryption = encryption;
    h.compression = compression;
    h.payloadSize = processedSize;

    logHeaderToPhonebook(&h);

    QString timestamp = QDateTime::currentDateTime().toString("yyyyMMdd-hhmmss");
    QString headerStr = QString("%1|%2|%3|%4|%5|%6|%7\n")
                            .arg(sid)
                            .arg(rid)
                            .arg(priority)
                            .arg(encryption)
                            .arg(compression)
                            .arg(processedSize)
                            .arg(timestamp);

    QByteArray headerBytes = headerStr.toLocal8Bit();

    int totalSize = headerBytes.size() + processedSize;
    unsigned char* fullMessage = (unsigned char*)malloc(totalSize);

    memcpy(fullMessage, headerBytes.constData(), headerBytes.size());
    memcpy(fullMessage + headerBytes.size(), processedData, processedSize);

    outputToPort(&m_hComTx, fullMessage, totalSize);

    qDebug() << "Sent AUDIO message: SID=" << sid << "RID=" << rid;

    free(fullMessage);
    if (needsFree && processedData) {
        free(processedData);
    }

    emit messageSent(true, QString("Audio sent (SID:%1 RID:%2)").arg(sid).arg(rid));
    return true;
}

QString CMSController::receiveTextMessage()
{
    if (!systemsInitialized) {
        emit errorOccurred("Systems not initialized");
        return QString();
    }

    if (m_hComRx == INVALID_HANDLE_VALUE) {
        if (!initializeReceiver()) {
            if (!initializeReceiver("COM6")) {
                QString simulatedMessage = "Simulated received message (COM ports not available)\n"
                                           "Time: " + QDateTime::currentDateTime().toString();
                emit messageReceived(simulatedMessage);
                return simulatedMessage;
            }
        }
    }

    char buffer[4096];
    DWORD bytesRead = inputFromPort(&m_hComRx, buffer, sizeof(buffer));

    if (bytesRead > 0) {
        buffer[bytesRead] = '\0';

        QString fullData = QString::fromLocal8Bit(buffer, bytesRead);

        int headerEnd = fullData.indexOf('\n');
        if (headerEnd > 0) {
            QString headerStr = fullData.left(headerEnd);
            QString payloadStr = fullData.mid(headerEnd + 1);

            QStringList headerParts = headerStr.split('|');
            if (headerParts.size() >= 7) {
                int sid = headerParts[0].toInt();
                int rid = headerParts[1].toInt();
                int priority = headerParts[2].toInt();
                int encryption = headerParts[3].toInt();
                int compression = headerParts[4].toInt();
                int payloadSize = headerParts[5].toInt();
                QString timestamp = headerParts[6];

                qDebug() << "Received TEXT: SID=" << sid << "RID=" << rid;

                QByteArray payloadBytes = payloadStr.toLocal8Bit();
                unsigned char* payloadData = (unsigned char*)payloadBytes.data();
                int actualSize = payloadBytes.size();

                if (compression == 1) {
                    qDebug() << "Decompressing Huffman...";
                    int decompressedSize = 0;
                    unsigned char* decompressed = huffman_decode(payloadData, actualSize, &decompressedSize);
                    if (decompressed) {
                        payloadBytes = QByteArray((char*)decompressed, decompressedSize);
                        free(decompressed);
                        qDebug() << "Huffman decompression successful";
                    }
                } else if (compression == 2) {
                    qDebug() << "Decompressing RLE...";
                    int decompressedSize = 0;
                    unsigned char* decompressed = rle_decode(payloadData, actualSize, &decompressedSize);
                    if (decompressed) {
                        payloadBytes = QByteArray((char*)decompressed, decompressedSize);
                        free(decompressed);
                        qDebug() << "RLE decompression successful";
                    }
                }

                if (encryption == 1) {
                    qDebug() << "Applying XOR decryption...";
                    xor_decrypt((unsigned char*)payloadBytes.data(), payloadBytes.size());
                    qDebug() << "XOR decryption applied";
                }

                QString decryptedMessage = QString::fromLocal8Bit(payloadBytes);
                QString finalMessage = headerStr + "\n" + decryptedMessage;

                emit messageReceived(finalMessage);
                return finalMessage;
            }
        }

        qDebug() << "Received message without proper header";
        emit messageReceived(fullData);
        return fullData;
    }

    return QString();
}

bool CMSController::receiveAudioMessage()
{
    if (!systemsInitialized) {
        emit errorOccurred("Systems not initialized");
        return false;
    }

    if (m_hComRx == INVALID_HANDLE_VALUE) {
        if (!initializeReceiver()) {
            emit errorOccurred("Receiver not initialized");
            return false;
        }
    }

    unsigned char buffer[100000];
    DWORD bytesRead = inputFromPort(&m_hComRx, buffer, sizeof(buffer));

    if (bytesRead > 0) {
        qDebug() << "Received" << bytesRead << "bytes";

        QString headerStr;
        int headerEnd = 0;

        for (int i = 0; i < (int)bytesRead; i++) {
            if (buffer[i] == '\n') {
                headerEnd = i + 1;
                headerStr = QString::fromLocal8Bit((char*)buffer, i);
                break;
            }
        }

        if (headerEnd > 0 && headerStr.contains('|')) {
            QStringList parts = headerStr.split('|');
            if (parts.size() >= 7) {
                int sid = parts[0].toInt();
                int rid = parts[1].toInt();
                int priority = parts[2].toInt();
                int encryption = parts[3].toInt();
                int compression = parts[4].toInt();
                int payloadSize = parts[5].toInt();

                qDebug() << "Received AUDIO: SID=" << sid << "RID=" << rid;

                unsigned char* audioData = buffer + headerEnd;
                int audioSize = bytesRead - headerEnd;

                unsigned char* processedData = audioData;
                int processedSize = audioSize;
                bool needsFree = false;

                if (compression == 1) {
                    qDebug() << "Decompressing Huffman...";
                    int decompSize = 0;
                    unsigned char* decompressed = huffman_decode(audioData, audioSize, &decompSize);
                    if (decompressed) {
                        processedData = decompressed;
                        processedSize = decompSize;
                        needsFree = true;
                    }
                } else if (compression == 2) {
                    qDebug() << "Decompressing RLE...";
                    int decompSize = 0;
                    unsigned char* decompressed = rle_decode(audioData, audioSize, &decompSize);
                    if (decompressed) {
                        processedData = decompressed;
                        processedSize = decompSize;
                        needsFree = true;
                    }
                }

                if (encryption == 1) {
                    qDebug() << "Applying XOR decryption...";
                    xor_decrypt(processedData, processedSize);
                }

                short* audioSamples = (short*)processedData;
                long sampleCount = processedSize / sizeof(short);

                QString audioName = QString("RxAudio_SID%1_RID%2").arg(sid).arg(rid);
                QByteArray nameBytes = audioName.toLocal8Bit();

                enqueue(audioSamples, sampleCount, nameBytes.constData());

                if (needsFree) {
                    free(processedData);
                }

                qDebug() << "Audio message added to queue:" << audioName;
                emit messageReceived("Audio message received");
                return true;
            }
        }
    }

    return false;
}

int CMSController::getMessageCount() const
{
    return messageCount;
}

QString CMSController::getCurrentMessageName() const
{
    if (isQueueEmpty()) {
        return QString();
    }

    link frontNode = peekQueue();
    if (frontNode) {
        return QString::fromLocal8Bit(frontNode->Data.filename);
    }

    return QString();
}

void CMSController::loadConfigFromFile()
{
    loadConfig("cms_config.txt", &g_config);
    if (g_config.contactCount > 0) {
        qDebug() << "config loaded:" << g_config.contactCount << "contacts";
    } else {
        qDebug() << "config not found, using defaults";
        setDefaultConfig(&g_config);
        saveConfig("cms_config.txt", &g_config);
    }
}

void CMSController::saveConfigToFile()
{
    saveConfig("cms_config.txt", &g_config);
    qDebug() << "config saved";
}

int CMSController::getContactCount() const
{
    return g_config.contactCount;
}

bool CMSController::addContact(const QString& name, int sid, int rid, const QString& port)
{
    if (g_config.contactCount >= MAX_CONTACTS) {
        qDebug() << "Contact list full";
        return false;
    }

    QByteArray nameBa = name.toLocal8Bit();
    QByteArray portBa = port.toLocal8Bit();

    // Manually add to config structure
    strncpy(g_config.contacts[g_config.contactCount].name, nameBa.constData(), 31);
    g_config.contacts[g_config.contactCount].name[31] = '\0';
    g_config.contacts[g_config.contactCount].sid = sid;
    g_config.contacts[g_config.contactCount].rid = rid;
    strncpy(g_config.contacts[g_config.contactCount].comPort, portBa.constData(), 7);
    g_config.contacts[g_config.contactCount].comPort[7] = '\0';

    g_config.contactCount++;

    saveConfigToFile();
    qDebug() << "added contact:" << name;
    return true;
}

bool CMSController::editContact(int index, const QString& name, int sid, int rid, const QString& port)
{
    if (index < 0 || index >= g_config.contactCount) {
        return false;
    }

    QByteArray nameBa = name.toLocal8Bit();
    QByteArray portBa = port.toLocal8Bit();

    strncpy(g_config.contacts[index].name, nameBa.constData(), 31);
    g_config.contacts[index].name[31] = '\0';
    g_config.contacts[index].sid = sid;
    g_config.contacts[index].rid = rid;
    strncpy(g_config.contacts[index].comPort, portBa.constData(), 7);
    g_config.contacts[index].comPort[7] = '\0';

    saveConfigToFile();
    qDebug() << "edited contact:" << name;
    return true;
}

bool CMSController::removeContact(int index)
{
    if (index < 0 || index >= g_config.contactCount) {
        return false;
    }

    // Shift all contacts down
    for (int i = index; i < g_config.contactCount - 1; i++) {
        g_config.contacts[i] = g_config.contacts[i + 1];
    }

    g_config.contactCount--;

    saveConfigToFile();
    qDebug() << "removed contact at index" << index;
    return true;
}

void CMSController::refreshContacts(QTableWidget* table)
{
    if (!table) return;

    table->setRowCount(0);

    for (int i = 0; i < g_config.contactCount; i++) {
        table->insertRow(i);
        table->setItem(i, 0, new QTableWidgetItem(QString::fromLocal8Bit(g_config.contacts[i].name)));
        table->setItem(i, 1, new QTableWidgetItem(QString::number(g_config.contacts[i].sid)));
        table->setItem(i, 2, new QTableWidgetItem(QString::number(g_config.contacts[i].rid)));
        table->setItem(i, 3, new QTableWidgetItem(QString::fromLocal8Bit(g_config.contacts[i].comPort)));
    }
}

QString CMSController::getContactName(int index) const
{
    if (index < 0 || index >= g_config.contactCount) {
        return QString();
    }
    return QString::fromLocal8Bit(g_config.contacts[index].name);
}

int CMSController::getContactSID(int index) const
{
    if (index < 0 || index >= g_config.contactCount) {
        return 0;
    }
    return g_config.contacts[index].sid;
}

int CMSController::getContactRID(int index) const
{
    if (index < 0 || index >= g_config.contactCount) {
        return 0;
    }
    return g_config.contacts[index].rid;
}

QString CMSController::getContactPort(int index) const
{
    if (index < 0 || index >= g_config.contactCount) {
        return QString();
    }
    return QString::fromLocal8Bit(g_config.contacts[index].comPort);
}

QString CMSController::getTxPort() const
{
    return QString::fromLocal8Bit(g_config.txPort);
}

QString CMSController::getRxPort() const
{
    return QString::fromLocal8Bit(g_config.rxPort);
}

int CMSController::getBaudRate() const
{
    return g_config.baudRate;
}

int CMSController::getDefaultSID() const
{
    return g_config.defaultSID;
}

int CMSController::getDefaultRID() const
{
    return g_config.defaultRID;
}

int CMSController::getDefaultPriority() const
{
    return g_config.defaultPriority;
}

void CMSController::setTxPort(const QString& port)
{
    QByteArray ba = port.toLocal8Bit();
    strncpy(g_config.txPort, ba.constData(), 7);
    g_config.txPort[7] = '\0';
}

void CMSController::setRxPort(const QString& port)
{
    QByteArray ba = port.toLocal8Bit();
    strncpy(g_config.rxPort, ba.constData(), 7);
    g_config.rxPort[7] = '\0';
}

void CMSController::setBaudRate(int baud)
{
    g_config.baudRate = baud;
}

void CMSController::setDefaultSID(int sid)
{
    g_config.defaultSID = sid;
}

void CMSController::setDefaultRID(int rid)
{
    g_config.defaultRID = rid;
}

void CMSController::setDefaultPriority(int priority)
{
    g_config.defaultPriority = priority;
}
