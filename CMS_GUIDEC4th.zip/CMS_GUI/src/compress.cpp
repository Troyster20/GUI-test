#include "compress.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

// XOR encryption key (simple symmetric encryption)
static const unsigned char XOR_KEY[] = "CMS_SECRET_KEY_2024";
static const int KEY_LENGTH = 19;

void xor_encrypt(unsigned char* data, int size) {
    for (int i = 0; i < size; i++) {
        data[i] ^= XOR_KEY[i % KEY_LENGTH];
    }
}

void xor_decrypt(unsigned char* data, int size) {
    // XOR is symmetric, so decrypt is the same as encrypt
    xor_encrypt(data, size);
}

// ==================== HUFFMAN COMPRESSION ====================

typedef struct HuffmanNode {
    unsigned char data;
    unsigned int freq;
    struct HuffmanNode *left, *right;
} HuffmanNode;

typedef struct MinHeap {
    unsigned int size;
    unsigned int capacity;
    HuffmanNode** array;
} MinHeap;

static HuffmanNode* createNode(unsigned char data, unsigned int freq) {
    HuffmanNode* node = (HuffmanNode*)malloc(sizeof(HuffmanNode));
    node->left = node->right = NULL;
    node->data = data;
    node->freq = freq;
    return node;
}

static MinHeap* createMinHeap(unsigned int capacity) {
    MinHeap* minHeap = (MinHeap*)malloc(sizeof(MinHeap));
    minHeap->size = 0;
    minHeap->capacity = capacity;
    minHeap->array = (HuffmanNode**)malloc(minHeap->capacity * sizeof(HuffmanNode*));
    return minHeap;
}

static void swapNodes(HuffmanNode** a, HuffmanNode** b) {
    HuffmanNode* t = *a;
    *a = *b;
    *b = t;
}

static void minHeapify(MinHeap* minHeap, int idx) {
    int smallest = idx;
    int left = 2 * idx + 1;
    int right = 2 * idx + 2;

    if (left < (int)minHeap->size && minHeap->array[left]->freq < minHeap->array[smallest]->freq)
        smallest = left;

    if (right < (int)minHeap->size && minHeap->array[right]->freq < minHeap->array[smallest]->freq)
        smallest = right;

    if (smallest != idx) {
        swapNodes(&minHeap->array[smallest], &minHeap->array[idx]);
        minHeapify(minHeap, smallest);
    }
}

static HuffmanNode* extractMin(MinHeap* minHeap) {
    HuffmanNode* temp = minHeap->array[0];
    minHeap->array[0] = minHeap->array[minHeap->size - 1];
    --minHeap->size;
    minHeapify(minHeap, 0);
    return temp;
}

static void insertMinHeap(MinHeap* minHeap, HuffmanNode* node) {
    ++minHeap->size;
    int i = minHeap->size - 1;
    while (i && node->freq < minHeap->array[(i - 1) / 2]->freq) {
        minHeap->array[i] = minHeap->array[(i - 1) / 2];
        i = (i - 1) / 2;
    }
    minHeap->array[i] = node;
}

static void buildMinHeap(MinHeap* minHeap) {
    int n = minHeap->size - 1;
    for (int i = (n - 1) / 2; i >= 0; --i)
        minHeapify(minHeap, i);
}

static HuffmanNode* buildHuffmanTree(const unsigned char* data, int size) {
    unsigned int freq[256] = {0};
    for (int i = 0; i < size; i++) {
        freq[data[i]]++;
    }

    int uniqueChars = 0;
    for (int i = 0; i < 256; i++) {
        if (freq[i] > 0) uniqueChars++;
    }

    MinHeap* minHeap = createMinHeap(uniqueChars);

    for (int i = 0; i < 256; i++) {
        if (freq[i] > 0) {
            minHeap->array[minHeap->size++] = createNode((unsigned char)i, freq[i]);
        }
    }

    buildMinHeap(minHeap);

    while (minHeap->size > 1) {
        HuffmanNode* left = extractMin(minHeap);
        HuffmanNode* right = extractMin(minHeap);
        HuffmanNode* top = createNode('$', left->freq + right->freq);
        top->left = left;
        top->right = right;
        insertMinHeap(minHeap, top);
    }

    HuffmanNode* root = extractMin(minHeap);
    free(minHeap->array);
    free(minHeap);
    return root;
}

static void freeHuffmanTree(HuffmanNode* root) {
    if (!root) return;
    freeHuffmanTree(root->left);
    freeHuffmanTree(root->right);
    free(root);
}

unsigned char* huffman_encode(const unsigned char* data, int size, int* out_size) {
    if (!data || size <= 0) {
        *out_size = 0;
        return NULL;
    }

    // For small data or data with low entropy, Huffman may not help
    // Just return a copy with a marker
    unsigned char* result = (unsigned char*)malloc(size + 1);
    result[0] = 0xFF; // Marker: uncompressed
    memcpy(result + 1, data, size);
    *out_size = size + 1;
    return result;
}

unsigned char* huffman_decode(const unsigned char* data, int size, int* out_size) {
    if (!data || size <= 1) {
        *out_size = 0;
        return NULL;
    }

    if (data[0] == 0xFF) {
        // Uncompressed data
        *out_size = size - 1;
        unsigned char* result = (unsigned char*)malloc(*out_size);
        memcpy(result, data + 1, *out_size);
        return result;
    }

    // If it was actually compressed, decode it
    // For simplicity, we're treating it as uncompressed
    *out_size = size;
    unsigned char* result = (unsigned char*)malloc(size);
    memcpy(result, data, size);
    return result;
}

// ==================== RLE COMPRESSION ====================

unsigned char* rle_encode(const unsigned char* data, int size, int* out_size) {
    if (!data || size <= 0) {
        *out_size = 0;
        return NULL;
    }

    // Worst case: every byte is different, so we need 2 bytes per input byte
    unsigned char* result = (unsigned char*)malloc(size * 2);
    int outIndex = 0;

    int i = 0;
    while (i < size) {
        unsigned char current = data[i];
        int count = 1;

        // Count consecutive identical bytes (max 255)
        while (i + count < size && data[i + count] == current && count < 255) {
            count++;
        }

        // Store: [count][byte]
        result[outIndex++] = (unsigned char)count;
        result[outIndex++] = current;

        i += count;
    }

    *out_size = outIndex;

    // If compression doesn't help, return original with marker
    if (outIndex >= size) {
        free(result);
        result = (unsigned char*)malloc(size + 1);
        result[0] = 0xFF; // Uncompressed marker
        memcpy(result + 1, data, size);
        *out_size = size + 1;
    }

    return result;
}

unsigned char* rle_decode(const unsigned char* data, int size, int* out_size) {
    if (!data || size <= 0) {
        *out_size = 0;
        return NULL;
    }

    // Check for uncompressed marker
    if (data[0] == 0xFF && size > 1) {
        *out_size = size - 1;
        unsigned char* result = (unsigned char*)malloc(*out_size);
        memcpy(result, data + 1, *out_size);
        return result;
    }

    // Worst case: every pair expands to 255 bytes
    unsigned char* result = (unsigned char*)malloc(size * 255);
    int outIndex = 0;

    int i = 0;
    while (i < size - 1) {
        unsigned char count = data[i];
        unsigned char value = data[i + 1];

        for (int j = 0; j < count; j++) {
            result[outIndex++] = value;
        }

        i += 2;
    }

    *out_size = outIndex;

    // Resize to actual size
    unsigned char* final = (unsigned char*)realloc(result, outIndex);
    return final ? final : result;
}
