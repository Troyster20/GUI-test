#ifndef SOUND_H
#define SOUND_H

#include <windows.h>

#define DEFAULT_NSAMPLES 4000
#define MIN_BUFSIZE 1000
#define RECORD_TIME 6
#define SAMPLES_SEC 8000
#define NFREQUENCIES 96

extern short iBigBuf[];
extern long lBigBufSize;


int InitializePlayback(void);
int PlayBuffer(short *piBuf, long lSamples);
void ClosePlayback(void);


int InitializeRecording(void);
int RecordBuffer(short *piBuf, long lBufSize);
void CloseRecording(void);


void saveAudio(short* buffer, long size, const char* filename);


#endif //SOUND_H
