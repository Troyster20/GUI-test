#ifndef CONFIG_H
#define CONFIG_H

#define MAX_CONTACTS 50

typedef struct {
    char name[32];
    int sid;
    int rid;
    char comPort[8];
} Contact;

typedef struct {
    char txPort[8];
    char rxPort[8];
    int baudRate;
    int defaultSID;
    int defaultRID;
    int defaultPriority;
    int contactCount;
    Contact contacts[MAX_CONTACTS];
} Config;

#ifdef __cplusplus
extern "C" {
#endif

void setDefaultConfig(Config* cfg);
int loadConfig(const char* filename, Config* cfg);
int saveConfig(const char* filename, Config* cfg);

#ifdef __cplusplus
}
#endif

#endif
