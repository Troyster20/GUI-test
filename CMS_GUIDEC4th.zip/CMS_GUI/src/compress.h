#ifndef COMPRESS_H
#define COMPRESS_H

#ifdef __cplusplus
extern "C" {
#endif

// XOR Encryption/Decryption
void xor_encrypt(unsigned char* data, int size);
void xor_decrypt(unsigned char* data, int size);

// Huffman Compression/Decompression
unsigned char* huffman_encode(const unsigned char* data, int size, int* out_size);
unsigned char* huffman_decode(const unsigned char* data, int size, int* out_size);

// RLE Compression/Decompression
unsigned char* rle_encode(const unsigned char* data, int size, int* out_size);
unsigned char* rle_decode(const unsigned char* data, int size, int* out_size);

#ifdef __cplusplus
}
#endif

#endif // COMPRESS_H
