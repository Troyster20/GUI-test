#ifndef ENCRYPTION_H
#define ENCRYPTION_H

#ifdef __cplusplus
extern "C" {
#endif

void xorEncrypt(const char* input, char* output, char key, int length);
void xorDecrypt(const char* input, char* output, char key, int length);

#ifdef __cplusplus
}
#endif

#endif
