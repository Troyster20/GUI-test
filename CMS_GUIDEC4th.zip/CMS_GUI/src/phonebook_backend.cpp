#include "phonebook_backend.h"
#include <stdio.h>
#include <time.h>
#include <string.h>

extern "C" {

void logHeaderToPhonebook(Header* h) {
    FILE* f = fopen("phonebook.log", "a");
    if (!f) return;

    time_t now = time(NULL);
    char timestamp[64];
    strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S", localtime(&now));

    fprintf(f, "[%s] SID:%d RID:%d PRI:%d TYPE:%d ENC:%d COMP:%d SIZE:%ld\n",
            timestamp, h->sid, h->rid, h->priority, h->payLoadType,
            h->encryption, h->compression, h->payloadSize);

    fclose(f);
}

int fnumLogs() {
    FILE* f = fopen("phonebook.log", "r");
    if (!f) return 0;

    int count = 0;
    char line[256];
    while (fgets(line, sizeof(line), f)) {
        count++;
    }

    fclose(f);
    return count;
}

} // extern "C"
