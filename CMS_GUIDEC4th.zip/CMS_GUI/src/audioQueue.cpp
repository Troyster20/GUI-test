#include "audioQueue.h"

link front = NULL;
link rear = NULL;
int messageCount = 0;

extern "C" {

void initQueue(){
    front = rear = NULL;
}

int isQueueEmpty(){
    return (front == NULL);
}

void enqueue(short* buf, long size, const char* name){
    link newNode = (link)malloc(sizeof(Node));
    if (newNode == NULL) {
        printf("ERROR: malloc failed for queuing new node\n");
        return;
    }

    newNode->Data.buffer = (short*)malloc(size * sizeof(short));
    if (newNode->Data.buffer == NULL) {
        printf("ERROR: malloc failed for message buffer\n");
        free(newNode);
        return;
    }

    memcpy(newNode->Data.buffer, buf, size * sizeof(short));
    newNode->Data.size = size;
    strncpy_s(newNode->Data.filename, MAX_FILENAME, name, _TRUNCATE);
    newNode->pNext = NULL;

    if (isQueueEmpty()) {
        front = rear = newNode;
    }
    else {
        rear->pNext = newNode;
        rear = newNode;
    }
    messageCount++;
    printf("Message enqueued. Total messages: %d\n", messageCount);
}

link deQueue(){
    if (isQueueEmpty()) {
        printf("The queue is empty\n");
        return NULL;
    }

    link temp = front;
    front = front->pNext;
    if (front == NULL) {
        rear = NULL;
    }

    messageCount--;
    printf("Dequeued message. Remaining messages: %d\n", messageCount);
    return temp;
}

void clearQueue(){
    while (!isQueueEmpty()) {
        link temp = deQueue();
        if (temp) {
            free(temp->Data.buffer);
            free(temp);
        }
    }
}

link peekQueue() {
    if (isQueueEmpty()) {
        printf("Queue is empty\n");
        return NULL;
    }
    return front;
}

} // extern "C"
