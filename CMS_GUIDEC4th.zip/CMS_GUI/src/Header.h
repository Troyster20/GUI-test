#ifndef HEADER_H
#define HEADER_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    short int sid;
    short int rid;
    int priority;
    long int payloadSize;
    int payLoadType;
    int encryption;
    int compression;
} Header;

#ifdef __cplusplus
}
#endif

#endif // HEADER_H
