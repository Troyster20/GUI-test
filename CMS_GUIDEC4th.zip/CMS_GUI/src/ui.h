#pragma once

#include <Windows.h>

enum SELECT_MODE {
    TRANSMITTER = 1,
    RECEIVER = 2,
    TESTING = 3,
    PHONEBOOK = 4,
    SETTINGS = 5,
    QUIT = 6
};

enum TRANSMITTER_CHOICES {
    NEW_TEXT = 1,
    NEW_AUDIO = 2,
    Tx_GO_BACK = 3
};

enum RECEIVER_CHOICES {
    PLAY_TEXT = 1,
    PLAY_AUDIO = 2,
    Rx_GO_BACK = 3
};

extern short iBigBuf[];
extern long lBigBufSize;

#ifdef __cplusplus
extern "C" {
#endif

void recordNew();
void saveFront();
void playFront();
void deleteFront();
void quit();
void invalid();

int selectStation();
void receivingMenu();
void transmittingMenu();
void runModeLoop();

#ifdef __cplusplus
}
#endif
