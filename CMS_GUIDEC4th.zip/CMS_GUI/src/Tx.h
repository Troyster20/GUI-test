/*
===================================================== SECTION HEADER =====================================================

Program Name:   EECE72405-25F
Author:			KIEN MACARTNEY
Date:           OCT 30 2025
Comments:		Projects III - Coded Messaging System

                Transmitting header file

==========================================================================================================================
*/
#ifndef TX_H
#define TX_H

#ifdef _WIN32
#include <windows.h>
#endif

void newText(HANDLE* hComTx);
void Tx_goBack();
void transmitterLoop(HANDLE* hComTx);

#endif // TX_H
