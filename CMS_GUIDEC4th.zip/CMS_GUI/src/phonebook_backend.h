#ifndef PHONEBOOK_BACKEND_H
#define PHONEBOOK_BACKEND_H

#include "Header.h"

#ifdef __cplusplus
extern "C" {
#endif

void logHeaderToPhonebook(Header* h);
int fnumLogs();

#ifdef __cplusplus
}
#endif

#endif
