#include "encryption.h"

void xorEncrypt(const char* input, char* output, char key, int length) {
    for (int i = 0; i < length; i++) {
        output[i] = input[i] ^ key;
    }
}

void xorDecrypt(const char* input, char* output, char key, int length) {
    for (int i = 0; i < length; i++) {
        output[i] = input[i] ^ key;
    }
}
