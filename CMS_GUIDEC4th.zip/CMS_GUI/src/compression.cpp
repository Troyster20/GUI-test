#include "compression.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define MAX_TREE_NODES 512

typedef struct HuffmanNode {
    unsigned char symbol;
    unsigned long frequency;
    struct HuffmanNode* left;
    struct HuffmanNode* right;
} HuffmanNode;

typedef struct {
    unsigned char symbol;
    unsigned char code[256];
    int codeLength;
} HuffmanCode;

static HuffmanNode* createNode(unsigned char symbol, unsigned long frequency) {
    HuffmanNode* node = (HuffmanNode*)malloc(sizeof(HuffmanNode));
    node->symbol = symbol;
    node->frequency = frequency;
    node->left = NULL;
    node->right = NULL;
    return node;
}

static void buildCodes(HuffmanNode* root, unsigned char* code, int depth, HuffmanCode* codes) {
    if (!root) return;

    if (!root->left && !root->right) {
        codes[root->symbol].symbol = root->symbol;
        memcpy(codes[root->symbol].code, code, depth);
        codes[root->symbol].codeLength = depth;
        return;
    }

    if (root->left) {
        code[depth] = 0;
        buildCodes(root->left, code, depth + 1, codes);
    }

    if (root->right) {
        code[depth] = 1;
        buildCodes(root->right, code, depth + 1, codes);
    }
}

static void freeTree(HuffmanNode* root) {
    if (!root) return;
    freeTree(root->left);
    freeTree(root->right);
    free(root);
}

CompressedData huffmanCompress(const unsigned char* input, long inputSize) {
    CompressedData result;
    result.data = NULL;
    result.size = 0;

    if (!input || inputSize <= 0) return result;

    unsigned long frequencies[256] = {0};
    for (long i = 0; i < inputSize; i++) {
        frequencies[input[i]]++;
    }

    HuffmanNode* nodes[256];
    int nodeCount = 0;

    for (int i = 0; i < 256; i++) {
        if (frequencies[i] > 0) {
            nodes[nodeCount++] = createNode((unsigned char)i, frequencies[i]);
        }
    }

    if (nodeCount == 0) return result;

    if (nodeCount == 1) {
        nodes[nodeCount++] = createNode(0, 0);
    }

    while (nodeCount > 1) {
        int min1 = 0, min2 = 1;
        if (nodes[min2]->frequency < nodes[min1]->frequency) {
            int temp = min1;
            min1 = min2;
            min2 = temp;
        }

        for (int i = 2; i < nodeCount; i++) {
            if (nodes[i]->frequency < nodes[min1]->frequency) {
                min2 = min1;
                min1 = i;
            } else if (nodes[i]->frequency < nodes[min2]->frequency) {
                min2 = i;
            }
        }

        HuffmanNode* parent = createNode(0, nodes[min1]->frequency + nodes[min2]->frequency);
        parent->left = nodes[min1];
        parent->right = nodes[min2];

        if (min1 > min2) {
            int temp = min1;
            min1 = min2;
            min2 = temp;
        }

        nodes[min1] = parent;
        nodes[min2] = nodes[nodeCount - 1];
        nodeCount--;
    }

    HuffmanNode* root = nodes[0];

    HuffmanCode codes[256];
    memset(codes, 0, sizeof(codes));
    unsigned char code[256];
    buildCodes(root, code, 0, codes);

    long bitCount = 0;
    for (long i = 0; i < inputSize; i++) {
        bitCount += codes[input[i]].codeLength;
    }

    long compressedBytes = (bitCount + 7) / 8;
    long headerSize = sizeof(long) + 256 * sizeof(unsigned long);
    long totalSize = headerSize + compressedBytes;

    result.data = (unsigned char*)malloc(totalSize);
    result.size = totalSize;

    memcpy(result.data, &inputSize, sizeof(long));
    memcpy(result.data + sizeof(long), frequencies, 256 * sizeof(unsigned long));

    unsigned char* compressedData = result.data + headerSize;
    memset(compressedData, 0, compressedBytes);

    long bitPos = 0;
    for (long i = 0; i < inputSize; i++) {
        HuffmanCode* hc = &codes[input[i]];
        for (int j = 0; j < hc->codeLength; j++) {
            if (hc->code[j]) {
                compressedData[bitPos / 8] |= (1 << (7 - (bitPos % 8)));
            }
            bitPos++;
        }
    }

    freeTree(root);

    return result;
}

unsigned char* huffmanDecompress(const unsigned char* compressed, long compressedSize, long* outputSize) {
    if (!compressed || compressedSize < sizeof(long) + 256 * sizeof(unsigned long)) {
        *outputSize = 0;
        return NULL;
    }

    long originalSize;
    memcpy(&originalSize, compressed, sizeof(long));
    *outputSize = originalSize;

    unsigned long frequencies[256];
    memcpy(frequencies, compressed + sizeof(long), 256 * sizeof(unsigned long));

    HuffmanNode* nodes[256];
    int nodeCount = 0;

    for (int i = 0; i < 256; i++) {
        if (frequencies[i] > 0) {
            nodes[nodeCount++] = createNode((unsigned char)i, frequencies[i]);
        }
    }

    if (nodeCount == 0) {
        *outputSize = 0;
        return NULL;
    }

    if (nodeCount == 1) {
        nodes[nodeCount++] = createNode(0, 0);
    }

    while (nodeCount > 1) {
        int min1 = 0, min2 = 1;
        if (nodes[min2]->frequency < nodes[min1]->frequency) {
            int temp = min1;
            min1 = min2;
            min2 = temp;
        }

        for (int i = 2; i < nodeCount; i++) {
            if (nodes[i]->frequency < nodes[min1]->frequency) {
                min2 = min1;
                min1 = i;
            } else if (nodes[i]->frequency < nodes[min2]->frequency) {
                min2 = i;
            }
        }

        HuffmanNode* parent = createNode(0, nodes[min1]->frequency + nodes[min2]->frequency);
        parent->left = nodes[min1];
        parent->right = nodes[min2];

        if (min1 > min2) {
            int temp = min1;
            min1 = min2;
            min2 = temp;
        }

        nodes[min1] = parent;
        nodes[min2] = nodes[nodeCount - 1];
        nodeCount--;
    }

    HuffmanNode* root = nodes[0];

    unsigned char* output = (unsigned char*)malloc(originalSize);

    long headerSize = sizeof(long) + 256 * sizeof(unsigned long);
    const unsigned char* compressedData = compressed + headerSize;

    HuffmanNode* current = root;
    long outputPos = 0;
    long bitPos = 0;

    while (outputPos < originalSize) {
        int bit = (compressedData[bitPos / 8] >> (7 - (bitPos % 8))) & 1;

        current = bit ? current->right : current->left;

        if (!current->left && !current->right) {
            output[outputPos++] = current->symbol;
            current = root;
        }

        bitPos++;
    }

    freeTree(root);

    return output;
}

void freeCompressedData(CompressedData* data) {
    if (data && data->data) {
        free(data->data);
        data->data = NULL;
        data->size = 0;
    }

}
