#ifndef COMPRESSION_H
#define COMPRESSION_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    unsigned char* data;
    long size;
} CompressedData;

// Fixed: returns CompressedData by value, not pointer
CompressedData huffmanCompress(const unsigned char* input, long inputSize);
unsigned char* huffmanDecompress(const unsigned char* compressed, long compressedSize, long* outputSize);
void freeCompressedData(CompressedData* data);

#ifdef __cplusplus
}
#endif

#endif
