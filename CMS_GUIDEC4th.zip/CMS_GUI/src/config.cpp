#include "config.h"
#include <stdio.h>
#include <string.h>

extern "C" {

void setDefaultConfig(Config* cfg) {
    strcpy(cfg->txPort, "COM6");
    strcpy(cfg->rxPort, "COM7");
    cfg->baudRate = 115200;
    cfg->defaultSID = 1;
    cfg->defaultRID = 2;
    cfg->defaultPriority = 3;
    cfg->contactCount = 0;
}

int loadConfig(const char* filename, Config* cfg) {
    FILE* f = fopen(filename, "r");
    if (!f) {
        return 0;
    }

    fscanf(f, "%7s %7s %d %d %d %d\n",
           cfg->txPort, cfg->rxPort, &cfg->baudRate,
           &cfg->defaultSID, &cfg->defaultRID, &cfg->defaultPriority);

    fscanf(f, "%d\n", &cfg->contactCount);

    for (int i = 0; i < cfg->contactCount && i < MAX_CONTACTS; i++) {
        fscanf(f, "%31[^,],%d,%d,%7[^\n]\n",
               cfg->contacts[i].name,
               &cfg->contacts[i].sid,
               &cfg->contacts[i].rid,
               cfg->contacts[i].comPort);
    }

    fclose(f);
    return 1;
}

int saveConfig(const char* filename, Config* cfg) {
    FILE* f = fopen(filename, "w");
    if (!f) {
        return 0;
    }

    fprintf(f, "%s %s %d %d %d %d\n",
            cfg->txPort, cfg->rxPort, cfg->baudRate,
            cfg->defaultSID, cfg->defaultRID, cfg->defaultPriority);

    fprintf(f, "%d\n", cfg->contactCount);

    for (int i = 0; i < cfg->contactCount; i++) {
        fprintf(f, "%s,%d,%d,%s\n",
                cfg->contacts[i].name,
                cfg->contacts[i].sid,
                cfg->contacts[i].rid,
                cfg->contacts[i].comPort);
    }

    fclose(f);
    return 1;
}

} // extern "C"
