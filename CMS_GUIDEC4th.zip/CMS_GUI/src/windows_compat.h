#ifndef WINDOWS_COMPAT_H
#define WINDOWS_COMPAT_H
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX

#include <windows.h>
#include <mmsystem.h>

#undef WIN32_LEAN_AND_MEAN

#endif // WINDOWS_COMPAT_H
