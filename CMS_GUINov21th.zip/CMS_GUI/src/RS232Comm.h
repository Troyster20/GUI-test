#ifndef RS232COMM_H
#define RS232COMM_H

#ifdef __cplusplus
extern "C" {
#endif

#include <windows.h>

#define BUFSIZE 140

// Header structure - ONLY what we need
typedef struct {
    short int sid;
    short int rid;
    char priority;
    short int seqNum;
    long int payloadSize;
    char payLoadType;
    int encryption;
    int compression;
} Header;

// Global variables
extern int nComRate;
extern int nComBits;
extern COMMTIMEOUTS timeout;

// Core functions - ONLY what we need
void purgePort(HANDLE* hCom);
void outputToPort(HANDLE* hCom, LPCVOID buf, DWORD szBuf);
DWORD inputFromPort(HANDLE* hCom, LPVOID buf, DWORD szBuf);
HANDLE setupComPort(const wchar_t* portName, int nComRate, int nComBits, COMMTIMEOUTS timeout);

// Audio transmission - the working algorithm
void transmit(Header* txHeader, void* txPayload, HANDLE* hCom);
DWORD receive(Header* rxHeader, void** rxPayload, HANDLE* hCom);

#ifdef __cplusplus
}
#endif

#endif
