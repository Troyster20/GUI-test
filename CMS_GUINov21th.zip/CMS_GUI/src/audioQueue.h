#ifndef AUDIOQUEUE_H
#define AUDIOQUEUE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_MESSAGES 10
#define MAX_FILENAME 64

typedef struct item Item;
typedef struct node Node;
typedef Node* link;

struct item {
    short* buffer;
    long size;
    char filename[MAX_FILENAME];
};

struct node {
    Item Data;
    link pNext;
};

extern link front;
extern link rear;
extern int messageCount;

// Original functions
void initQueue();
int isQueueEmpty();
void enqueue(short* buf, long size, const char* name);
link deQueue();
void clearQueue();
link peekQueue();

// NEW: Missing functions needed by CMSController
int getQueueSize();
link getMessageAtIndex(int index);

#endif
