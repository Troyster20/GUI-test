#include "Receiver.h"
#include "ui_Receiver.h"
#include <QMessageBox>
#include <QDateTime>
#include <QString>
#include <QStringList>

Receiver::Receiver(CMSController* controller, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Receiver),
    m_controller(controller),
    m_currentSender("Unknown"),
    m_isEncrypted(false),
    m_isCompressed(false)
{
    ui->setupUi(this);

    connect(m_controller, &CMSController::messageReceived, this, &Receiver::onMessageReceived);
    connect(m_controller, &CMSController::playbackFinished, this, &Receiver::onPlaybackFinished);
    connect(m_controller, &CMSController::errorOccurred, this, &Receiver::onErrorOccurred);

    if (!m_controller->initializeReceiver()) {
        QMessageBox::warning(this, "COM Port Warning",
                             "Receiver COM port initialization failed. Check that the COM port is available.");
    }

    updateQueueInfo();
}

Receiver::~Receiver()
{
    delete ui;
}

void Receiver::on_backButton_clicked()
{
    emit backToStart();
}

void Receiver::on_playTextButton_clicked()
{
    QMessageBox::information(this, "Receiving Text Message",
                             "Waiting for text message transmission (10 seconds timeout)");

    QString message = m_controller->receiveTextMessage();

    if (!message.isEmpty()) {
        if (message.contains('|') && message.contains('\n')) {
            int headerEnd = message.indexOf('\n');
            QString header = message.left(headerEnd);
            QString messageBody = message.mid(headerEnd + 1);

            parseMessageHeader(header);
            ui->receivedTextEdit->setPlainText(messageBody);
        } else {
            ui->receivedTextEdit->setPlainText(message);
            m_currentSender = "Unknown";
            m_messageTime = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
        }

        ui->senderLabel->setText("From: " + m_currentSender);
        ui->timeLabel->setText("Time: " + m_messageTime);
        ui->decryptCheckBox->setChecked(m_isEncrypted);
        ui->decompressCheckBox->setChecked(m_isCompressed);

        QString successMsg = QString("Text message received successfully!\n\nLength: %1 characters\nSender: %2")
                                 .arg(message.length())
                                 .arg(m_currentSender);
        QMessageBox::information(this, "Text Received", successMsg);
    } else {
        ui->receivedTextEdit->setPlainText("[No message received]");
        ui->senderLabel->setText("From: ---");
        ui->timeLabel->setText("Time: ---");

        QString errorMsg = "No text message received.\n\nPossible causes:\n- No transmission sent\n- Timeout\n- Cable not connected\n- COM port issue";
        QMessageBox::warning(this, "No Data Received", errorMsg);
    }
}

void Receiver::on_playAudioButton_clicked()
{
    QMessageBox::information(this, "Receiving Audio Message",
                             "Ready to receive audio transmission! Click OK, then start transmission from transmitter.");

    bool success = m_controller->receiveAudioMessage();

    if (success) {
        updateQueueInfo();
        QMessageBox::information(this, "Audio Received",
                                 "Audio message received successfully! The audio has been added to the queue.");
    }
}

void Receiver::on_viewHeaderButton_clicked()
{
    QString headerInfo = QString(
                             "RECEIVER STATUS\n\n"
                             "Communication Protocol:\n"
                             "Type: Header + Payload\n"
                             "Baud Rate: 460800 bps\n"
                             "Port: COM7\n\n"
                             "Last Received Message:\n"
                             "Sender: %1\n"
                             "Timestamp: %2\n"
                             "Encrypted: %3\n"
                             "Compressed: %4\n\n"
                             "Audio Queue: %5 messages\n\n"
                             "System Status: Ready")
                             .arg(m_currentSender)
                             .arg(m_messageTime)
                             .arg(m_isEncrypted ? "Yes" : "No")
                             .arg(m_isCompressed ? "Yes" : "No")
                             .arg(m_controller->getMessageCount());

    QMessageBox::information(this, "Receiver Information", headerInfo);
}

void Receiver::on_checkErrorsButton_clicked()
{
    QString message = ui->receivedTextEdit->toPlainText();

    bool hasErrors = false;
    QString errorReport = "ERROR DETECTION CHECK\n\n";

    if (message.isEmpty() || message == "[No message received]") {
        errorReport += "Status: No message to check\n\nPlease receive a message first.";
    } else {
        errorReport += QString("Message length: %1 characters\n\n").arg(message.length());

        if (message.contains("�") || message.contains("??")) {
            hasErrors = true;
            errorReport += "Character encoding errors detected\n";
        }

        if (!hasErrors) {
            errorReport += "No errors detected\n";
            errorReport += "Message integrity: OK\n";
            errorReport += "Transmission quality: Good\n";
            errorReport += "Character encoding: Valid";
        } else {
            errorReport += "\nWarning: Message may be corrupted\n";
            errorReport += "Possible transmission errors detected";
        }
    }

    errorReport += QString("\n\nQueue Status: %1 audio messages").arg(m_controller->getMessageCount());

    QMessageBox::information(this, "Error Detection Results", errorReport);
}

void Receiver::onMessageReceived(const QString& message)
{
    if (!message.isEmpty()) {
        if (message.contains('|') && message.contains('\n')) {
            int headerEnd = message.indexOf('\n');
            QString header = message.left(headerEnd);
            QString messageBody = message.mid(headerEnd + 1);

            parseMessageHeader(header);
            ui->receivedTextEdit->setPlainText(messageBody);
        } else {
            ui->receivedTextEdit->setPlainText(message);
        }

        ui->senderLabel->setText("From: " + m_currentSender);
        ui->timeLabel->setText("Time: " + m_messageTime);
    }
}

void Receiver::parseMessageHeader(const QString& header)
{
    m_currentSender = "Unknown";
    m_messageTime = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
    m_isEncrypted = false;
    m_isCompressed = false;

    QStringList parts = header.split('|');
    for (const QString& part : parts) {
        if (part.startsWith("TO:")) {
            m_currentSender = part.mid(3);
        } else if (part.startsWith("TIME:")) {
            QString timeStr = part.mid(5);
            QDateTime dt = QDateTime::fromString(timeStr, "yyyyMMdd-hhmmss");
            if (dt.isValid()) {
                m_messageTime = dt.toString("yyyy-MM-dd hh:mm:ss");
            }
        } else if (part.startsWith("ENCRYPT:")) {
            m_isEncrypted = (part.mid(8) == "Y");
        } else if (part.startsWith("COMPRESS:")) {
            m_isCompressed = (part.mid(9) == "Y");
        }
    }
}

void Receiver::onPlaybackFinished(bool success, const QString& message)
{
    if (success) {
        QMessageBox::information(this, "Playback Complete", message);
    } else {
        QMessageBox::critical(this, "Playback Error", message);
    }
}

void Receiver::onErrorOccurred(const QString& error)
{
    QMessageBox::critical(this, "Error", error);
}

void Receiver::updateQueueInfo()
{
    int messageCount = m_controller->getMessageCount();
    QString currentMessage = m_controller->getCurrentMessageName();

    QString queueInfo = QString("Audio queue: %1 messages\nCurrent: %2")
                            .arg(messageCount)
                            .arg(currentMessage.isEmpty() ? "None" : currentMessage);

    ui->playAudioButton->setToolTip(queueInfo);
}
