#include "Phonebook.h"
#include "ui_Phonebook.h"
#include <QMessageBox>
#include <QInputDialog>

Phonebook::Phonebook(CMSController* controller, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Phonebook),
    m_controller(controller)
{
    ui->setupUi(this);

    QStringList headers;
    headers << "Name" << "COM Port" << "Last Contact" << "Status";
    ui->contactsTable->setHorizontalHeaderLabels(headers);

    refreshContactList();
}

Phonebook::~Phonebook()
{
    delete ui;
}

void Phonebook::on_backButton_clicked()
{
    emit backToStart();
}

void Phonebook::on_addContactButton_clicked()
{
    bool ok;
    QString name = QInputDialog::getText(this, "Add Contact",
                                         "Enter contact name:",
                                         QLineEdit::Normal, "", &ok);
    if (ok && !name.isEmpty()) {
        QString comPort = QInputDialog::getText(this, "COM Port",
                                                "Enter COM port (e.g., COM6):",
                                                QLineEdit::Normal, "COM", &ok);
        if (ok && !comPort.isEmpty()) {
            int row = ui->contactsTable->rowCount();
            ui->contactsTable->insertRow(row);
            ui->contactsTable->setItem(row, 0, new QTableWidgetItem(name));
            ui->contactsTable->setItem(row, 1, new QTableWidgetItem(comPort));
            ui->contactsTable->setItem(row, 2, new QTableWidgetItem("Never"));
            ui->contactsTable->setItem(row, 3, new QTableWidgetItem("Offline"));

            QMessageBox::information(this, "Contact Added",
                                     QString("Contact '%1' added to phonebook.\n\n"
                                             "Port: %2\n"
                                             "Protocol: Header + Payload @ 460800 baud").arg(name).arg(comPort));
        }
    }
}

void Phonebook::on_editContactButton_clicked()
{
    int currentRow = ui->contactsTable->currentRow();
    if (currentRow >= 0) {
        QString currentName = ui->contactsTable->item(currentRow, 0)->text();
        QString currentPort = ui->contactsTable->item(currentRow, 1)->text();

        bool ok;
        QString newName = QInputDialog::getText(this, "Edit Contact",
                                                "Edit contact name:",
                                                QLineEdit::Normal, currentName, &ok);
        if (ok && !newName.isEmpty()) {
            QString newPort = QInputDialog::getText(this, "Edit COM Port",
                                                    "Edit COM port:",
                                                    QLineEdit::Normal, currentPort, &ok);
            if (ok) {
                ui->contactsTable->item(currentRow, 0)->setText(newName);
                ui->contactsTable->item(currentRow, 1)->setText(newPort);
                QMessageBox::information(this, "Contact Updated",
                                         QString("Contact information updated.\n\n"
                                                 "Name: %1\n"
                                                 "Port: %2").arg(newName).arg(newPort));
            }
        }
    } else {
        QMessageBox::warning(this, "No Selection", "Please select a contact to edit.");
    }
}

void Phonebook::on_deleteContactButton_clicked()
{
    int currentRow = ui->contactsTable->currentRow();
    if (currentRow >= 0) {
        QString contactName = ui->contactsTable->item(currentRow, 0)->text();
        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(this, "Delete Contact",
                                      QString("Are you sure you want to delete '%1'?").arg(contactName),
                                      QMessageBox::Yes | QMessageBox::No);

        if (reply == QMessageBox::Yes) {
            ui->contactsTable->removeRow(currentRow);
            QMessageBox::information(this, "Contact Deleted",
                                     QString("Contact '%1' deleted.").arg(contactName));
        }
    } else {
        QMessageBox::warning(this, "No Selection", "Please select a contact to delete.");
    }
}

void Phonebook::refreshContactList()
{
    ui->contactsTable->setRowCount(0);

    QStringList sampleContacts = {
        "Station Alpha,COM6,2025-11-13 14:30,Online",
        "Station Beta,COM7,2025-11-13 09:15,Online",
        "Control Center,COM8,2025-11-13 10:00,Offline"
    };

    for (const QString& contact : sampleContacts) {
        QStringList fields = contact.split(',');
        int row = ui->contactsTable->rowCount();
        ui->contactsTable->insertRow(row);
        for (int i = 0; i < fields.size(); i++) {
            ui->contactsTable->setItem(row, i, new QTableWidgetItem(fields[i]));
        }
    }
}
